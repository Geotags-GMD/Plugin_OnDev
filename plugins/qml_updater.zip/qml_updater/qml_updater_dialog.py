# qml_updater.py
from PyQt5.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QPushButton,
    QFileDialog,
    QLabel,
    QProgressBar
)
import requests
import os
import json
from qgis.core import QgsSettings

class QMLUpdaterDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.setWindowTitle("QML Updater")
        self.setFixedWidth(300)  # Adjusted the window size for better layout

        self.layout = QVBoxLayout()
        self.label = QLabel("Select a QML Folder:")
        self.layout.addWidget(self.label)

        self.button_select_folder = QPushButton("Select QML Folder")
        self.button_select_folder.clicked.connect(self.select_folder)
        self.layout.addWidget(self.button_select_folder)

        # Label to show the selected folder path
        self.folder_label = QLabel("No folder selected")
        self.layout.addWidget(self.folder_label)

        self.button_update_qml = QPushButton("Update QML Files")
        self.button_update_qml.clicked.connect(self.update_qml)
        self.layout.addWidget(self.button_update_qml)

        self.progress_bar = QProgressBar(self)
        self.progress_bar.setValue(0)
        self.layout.addWidget(self.progress_bar)

        self.setLayout(self.layout)

        self.settings = QgsSettings()
        self.qml_folder = self.settings.value("qml_updater/folder", "")  # Load saved folder path

        # Show the saved folder in the label if it exists
        if self.qml_folder:
            self.folder_label.setText(f"Selected Folder: {self.qml_folder}")

        self.github_repo = "https://raw.githubusercontent.com/kentemman-gmd/qml-store/refs/heads/main/qml-files/"
        self.json_file = "qml_files.json"  # The JSON file to load the QML names
        self.qml_files = self.load_qml_files()

    def load_qml_files(self):
        """Load QML file names from a JSON file."""
        url = f"{self.github_repo}{self.json_file}"
        try:
            response = requests.get(url)
            response.raise_for_status()  # Raise an error for bad responses
            json_data = response.json()
            return json_data.get("qml_files", [])
        except Exception as e:
            self.label.setText(f"Error loading QML files: {str(e)}")
            return []

    def select_folder(self):
        self.qml_folder = QFileDialog.getExistingDirectory(self, "Select QML Folder")
        if self.qml_folder:
            # Update the label to show the selected folder
            self.folder_label.setText(f"Selected Folder: {self.qml_folder}")
            # Save the selected folder in QGIS settings
            self.settings.setValue("qml_updater/folder", self.qml_folder)

    def update_qml(self):
        if not self.qml_folder:
            self.label.setText("Please select a QML folder first.")
            return

        total_files = len(self.qml_files)
        self.progress_bar.setMaximum(total_files)
        self.progress_bar.setValue(0)

        for index, qml_file in enumerate(self.qml_files):
            try:
                url = f"{self.github_repo}{qml_file}"
                response = requests.get(url, stream=True)
                response.raise_for_status()  # Raise an error for bad responses

                qml_path = os.path.join(self.qml_folder, qml_file)

                with open(qml_path, "wb") as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        if chunk:  # Filter out keep-alive new chunks
                            f.write(chunk)

                self.label.setText(f"Updated QML file downloaded: {qml_path}")
            except Exception as e:
                self.label.setText(f"Error downloading {qml_file}: {str(e)}")

            self.progress_bar.setValue(index + 1)

        self.label.setText("Download complete!")

class QMLUpdaterPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.dialog = QMLUpdaterDialog()

    def initGui(self):
        self.action = self.iface.addToolBar("QML Updater")
        self.action.setObjectName("QMLUpdater")
        self.action.triggered.connect(self.show_dialog)

    def show_dialog(self):
        self.dialog.exec_()

    def unload(self):
        self.iface.removeToolBar(self.action)

import os
import json
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QComboBox, QPushButton,
    QFileDialog, QProgressBar, QLabel
)
from qgis.core import QgsProject, QgsProcessingFeedback
import processing

# Function to load the JSON file containing QML paths
def load_json_file(file_path):
    with open(file_path, 'r') as f:
        return json.load(f)

# Function to load and apply QML styles to layers
def apply_style(layer, qml_path):
    success = layer.loadNamedStyle(qml_path)
    if success:
        print(f"Applied style from {qml_path} to layer: {layer.name()}")
    else:
        print(f"Failed to apply style from {qml_path} to layer: {layer.name()}")
    layer.triggerRepaint()

# Function to filter layers based on selected geocode
def filter_layers(layers, selected_geocode):
    layers['bgy'].setSubsetString(f"geocode = '{selected_geocode}'")
    first_8_digits = selected_geocode[:8]
    layers['ea2024'].setSubsetString(f"geocode LIKE '{first_8_digits}%'")
    layers['bldg_point'].setSubsetString(f"geocode LIKE '{first_8_digits}%'")

# Function to export selected features as GeoPackage
# Function to export selected features as GeoPackage
def export_selected_features(layers, layer_group_name, output_gpkg):
    selected_layers = [layer for layer in layers.values() if layer is not None and layer_group_name in layer.name()]
    
    if not selected_layers:
        print("No layers found for the selected group.")
        return

    alg_params = {
        'LAYERS': selected_layers,  # Pass the list of layers in the selected group
        'EXPORT_RELATED_LAYERS': False,  # Don't include related layers
        'OVERWRITE': True,  # Allow overwriting the file
        'SAVE_METADATA': True,  # Include metadata in the package
        'SAVE_STYLES': True,  # Save the layer styles
        'SELECTED_FEATURES_ONLY': True,  # Only include selected features
        'OUTPUT': output_gpkg  # The selected GeoPackage file
    }

    # Execute the packaging algorithm
    try:
        feedback = QgsProcessingFeedback()  # Create an instance of QgsProcessingFeedback
        results = processing.run("native:package", alg_params, feedback)  # Pass the instance
        if results:
            print(f"Export completed: {results['OUTPUT']}")
    except Exception as e:
        print(f"Error: {str(e)}")




class AuQCBMSDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("AUQCBMS")

        # Layout setup
        self.layout = QVBoxLayout(self)

        # Button to select QML folder
        self.select_path_button = QPushButton("Select QML Folder")
        self.select_path_button.clicked.connect(self.select_folder)
        self.layout.addWidget(self.select_path_button)

        # Label to show selected path
        self.path_label = QLabel("Selected Path: None")
        self.layout.addWidget(self.path_label)

        # Dropdown for geocode selection
        self.geocode_dropdown = QComboBox()
        self.layout.addWidget(self.geocode_dropdown)

        # Dropdown for layer group selection
        self.layer_group_dropdown = QComboBox()
        self.layout.addWidget(self.layer_group_dropdown)

        # Progress bar to show progress
        self.progress_bar = QProgressBar()
        self.layout.addWidget(self.progress_bar)

        # Button to run the process
        self.run_button = QPushButton("Run")
        self.run_button.clicked.connect(self.run)
        self.layout.addWidget(self.run_button)

        # Button to export selected features
        self.export_button = QPushButton("Export Selected Features")
        self.export_button.clicked.connect(self.export_features)
        self.layout.addWidget(self.export_button)

        # Initialize variables
        self.qml_folder_path = ""
        self.layers = {}

    def select_folder(self):
        # Open a dialog to select the QML folder
        self.qml_folder_path = QFileDialog.getExistingDirectory(self, "Select QML Folder")
        self.path_label.setText(f"Selected Path: {self.qml_folder_path}")
        self.load_json_and_layers()

    def load_json_and_layers(self):
        # Load QML paths from JSON file
        json_file_path = os.path.join(self.qml_folder_path, "qml_config.json")
        qml_data = load_json_file(json_file_path)

        # Define layer keywords
        layer_keywords = ['ea2024', 'bgy', 'bldg_point', 'block', 'landmark', 'road', 'river']
        self.layers = {key: None for key in layer_keywords}

        # Match layers in QGIS project to keywords
        for layer in QgsProject.instance().mapLayers().values():
            for keyword in layer_keywords:
                if keyword in layer.name():
                    self.layers[keyword] = layer

        # Populate geocode dropdown with unique geocodes
        if self.layers['bgy'] is not None:
            bgy_geocodes = self.layers['bgy'].uniqueValues(self.layers['bgy'].fields().indexOf('geocode'))
            self.geocode_dropdown.clear()
            self.geocode_dropdown.addItems(sorted(bgy_geocodes))
            print(f"Found {len(bgy_geocodes)} unique geocodes.")

        # Populate layer group dropdown with layer names
        self.layer_group_dropdown.clear()
        unique_layer_groups = sorted(set(layer.name().split('_')[0] for layer in self.layers.values() if layer is not None))
        self.layer_group_dropdown.addItems(unique_layer_groups)

    def run(self):
        if not self.qml_folder_path:
            print("No QML folder selected.")
            return
        
        # Load QML paths from JSON file
        json_file_path = os.path.join(self.qml_folder_path, "qml_config.json")
        qml_data = load_json_file(json_file_path)

        # Apply styles to layers
        layer_order = qml_data['layer_order']
        for index, layer_name in enumerate(layer_order):
            layer = self.layers.get(layer_name)
            if layer is not None:
                qml_file = qml_data['qml_files'].get(layer_name)
                if qml_file:
                    qml_path = os.path.join(self.qml_folder_path, qml_file)
                    apply_style(layer, qml_path)
                    self.progress_bar.setValue(int((index + 1) / len(layer_order) * 100))

        # Filter layers based on selected geocode
        selected_geocode = self.geocode_dropdown.currentText()
        filter_layers(self.layers, selected_geocode)
        self.progress_bar.setValue(100)

    def export_features(self):
        # Get the selected geocode from the bgy dropdown
        selected_geocode = self.geocode_dropdown.currentText()
        
        # Open a dialog to select the output GeoPackage file
        output_gpkg, _ = QFileDialog.getSaveFileName(self, "Save GeoPackage", 
                                                      os.path.join(self.qml_folder_path, f"{selected_geocode}.gpkg"), 
                                                      "GeoPackage files (*.gpkg)")
        
        if output_gpkg:
            layer_group_name = self.layer_group_dropdown.currentText()
            export_selected_features(self.layers, layer_group_name, output_gpkg)

import os
import json
from qgis.PyQt.QtWidgets import QAction, QFileDialog, QDialog
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsProject
from .auqcbms_dialog import AuQCBMSDialog

class AuQCBMS:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.dialog = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, 'icon.png')
        self.action = QAction(QIcon(icon_path), "AuQCBMS", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&AuQCBMS", self.action)

    def unload(self):
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginMenu("&AuQCBMS", self.action)

    def run(self):
        if self.dialog is None:
            self.dialog = AuQCBMSDialog()
        self.dialog.show()
        self.dialog.exec_()



10.2019:
* `Setting`argument `value_list` has been renamed to `allowed_values`. This is valid for all setting types implementations.

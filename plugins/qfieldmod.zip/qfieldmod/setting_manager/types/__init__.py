from .bool import Bool
from .color import Color
from .double import Double
from .dictionnary import Dictionary
from .integer import Integer
from .list import List
from .stringlist import Stringlist
from .string import String
from .enum import Enum, EnumType

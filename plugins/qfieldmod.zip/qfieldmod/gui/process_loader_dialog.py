from qgis.core import QgsProject, QgsVectorLayer, QgsRasterLayer,QgsCoordinateReferenceSystem, QgsVectorFileWriter, QgsCoordinateTransformContext, QgsMessageLog, Qgis
from PyQt5.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QPushButton,
    QFileDialog,
    QLabel,
    QMessageBox,
    QProgressBar
)
import os
import re
from osgeo import ogr
import shutil
from PyQt5.uic import loadUiType
from qgis.gui import QgsFileWidget
from qgis.utils import iface
import processing
DialogUi, _ = loadUiType(
    os.path.join(os.path.dirname(__file__), "../ui/process_loader.ui")
)

class ProcessLoaderDialog(QDialog, DialogUi):
    def __init__(self, iface):
        super().__init__()
        self.setupUi(self)

        self.iface = iface
        
        self.setWindowTitle("Data Source Manager | Processing")

        # Set up QgsFileWidget for base layer selection
        self.select_baselayer.setStorageMode(QgsFileWidget.StorageMode.GetFile)
        self.select_baselayer.setDialogTitle("Select Base Layer")
        self.select_baselayer.setFilter("GeoPackage files (*.gpkg)")

        # Set up QgsFileWidget for reference data folder selection
        self.select_geotag.setStorageMode(QgsFileWidget.StorageMode.GetDirectory)
        self.select_geotag.setDialogTitle("Select Folder")
        self.select_geotag.fileChanged.connect(self.select_refdata_folder)
        

        # Set up QgsFileWidget for raster layer selection
        self.select_rasterlayer.setStorageMode(QgsFileWidget.StorageMode.GetFile)
        self.select_rasterlayer.setDialogTitle("Select Raster Layer")
        self.select_rasterlayer.setFilter(" Raster Layer (*_img.gpkg)")
        # self.select_rasterlayer.setFilter(" Raster Layer (*_img.gpkg);;All files (*.*)")
        

        #Digitize

        # Set up QgsFileWidget for base layer selection
        self.select_baselayer_2.setStorageMode(QgsFileWidget.StorageMode.GetFile)
        self.select_baselayer_2.setDialogTitle("Select Base Layer")
        self.select_baselayer_2.setFilter("GeoPackage files (*.gpkg)")


        # Set up QgsFileWidget for raster layer selection
        self.select_rasterlayer_2.setStorageMode(QgsFileWidget.StorageMode.GetFile)
        self.select_rasterlayer_2.setDialogTitle("Select Raster Layer")
        self.select_rasterlayer_2.setFilter(" Raster Layer (*_img.gpkg)")


        self.run_button.clicked.connect(self.run_loading_process)
        self.run_button_2.clicked.connect(self.run_digitize)

        self.progress_bar.setRange(0, 100)

        self.selected_folder = ""
        self.selected_geotags = ""
        self.qml_folder = ""

        # Add items to selectGroup comboBox
        self.selectGroup.addItems(["Processing", "Digitize"])
        
        # Connect the comboBox to the handler
        self.selectGroup.currentTextChanged.connect(self.on_group_selection_changed)
        
        # Initially hide digiGroup
        self.digiGroup.hide()
        self.processGroup.show()

    def zoom_to_layer(self):
        # Retrieve all layers in the project
        layers = QgsProject.instance().mapLayers().values()

        # Iterate through each layer
        for layer in layers:
            # Check if the layer's name ends with 'bgy'
            if layer.name().endswith('_SF'):
                # Get the extent of the layer
                extent = layer.extent()
                # Set the map canvas to the layer's extent
                iface.mapCanvas().setExtent(extent)
                iface.mapCanvas().refresh()
                print(f"Zoomed to the extent of the layer: {layer.name()}")
                break
        else:
            print("No layer found with a name ending with 'bgy'.")
            
       

    def select_refdata_folder(self):
        """Handle the selection of the reference data folder."""
        self.refdata_folder = self.select_geotag.filePath()
        if self.refdata_folder:
            print(f"Selected Reference Data Folder: {self.refdata_folder}")
        else:
            print("No reference data folder selected.")

    def select_geotagging(self):
        """Load geotagging layers from the selected folder and return them."""
        sf_layer, gp_layer = None, None
        for file in os.listdir(self.selected_geotags):
            if file.endswith("_SF.shp"):
                # Remove the extension for the layer name
                layer_name = os.path.splitext(os.path.basename(file))[0]
                sf_layer = QgsVectorLayer(os.path.join(self.selected_geotags, file), layer_name, "ogr")
            elif file.endswith("_GP.shp"):
                # Remove the extension for the layer name
                layer_name = os.path.splitext(os.path.basename(file))[0]
                gp_layer = QgsVectorLayer(os.path.join(self.selected_geotags, file), layer_name, "ogr")

        # Add layers to project if valid
        project = QgsProject.instance()
        if sf_layer and sf_layer.isValid() and sf_layer.name() not in [layer.name() for layer in project.mapLayers().values()]:
            project.addMapLayer(sf_layer, False)
            print(f"Loaded SF layer: {sf_layer.name()}")
        else:
            sf_layer = None

        if gp_layer and gp_layer.isValid() and gp_layer.name() not in [layer.name() for layer in project.mapLayers().values()]:
            project.addMapLayer(gp_layer, False)
            print(f"Loaded GP layer: {gp_layer.name()}")
        else:
            gp_layer = None

        return sf_layer, gp_layer


    def run_loading_process(self):
        """Load layers from the selected folder and apply QML styles if layers are loaded."""
 
        self.selected_geotags = self.select_geotag.filePath()

        self.selected_file = self.select_baselayer.filePath()

        # Validate selected GeoTags
        if not self.selected_geotags:
            QMessageBox.warning(self, "Warning", "Please select a folder first.")
            return
        
        if not os.path.exists(self.selected_geotags):
            QMessageBox.critical(self, "Error", "Selected folder does not exist.")
            return

   

        # Extract the folder path from the selected file
        self.selected_folder = os.path.dirname(self.selected_file)
        if not os.path.exists(self.selected_folder):
            QMessageBox.critical(self, "Error", "Selected folder does not exist.")
            return
        
        if not self.selected_folder:
            QMessageBox.warning(self, "Warning", "Please select a folder first.")
            return
        
        if not os.path.exists(self.selected_folder):
            QMessageBox.critical(self, "Error", "Selected folder does not exist.")
            return
               

        # Load layers from the selected folder
        csv_layers = self.load_csv(self.selected_folder)
        
        # Process GeoTag layers
        sf_layer, gp_layer = self.select_geotagging()

        project = QgsProject.instance()
        root = project.layerTreeRoot()

        # Create or retrieve CBMS Form 8 group
        cbms_group = root.findGroup("CBMS Form 8")
        if cbms_group is None:
            cbms_group = root.addGroup("CBMS Form 8")

        self.progress_bar.setValue(10)

        # Add SF layer to CBMS group
        if sf_layer and sf_layer.isValid():
            project.addMapLayer(sf_layer, False)
            cbms_group.addLayer(sf_layer)
        else:
            QMessageBox.critical(self, "Error", "SF layer failed to load!")

        self.progress_bar.setValue(30)

        # Add GP layer to CBMS group
        if gp_layer and gp_layer.isValid():
            project.addMapLayer(gp_layer, False)
            cbms_group.addLayer(gp_layer)
        else:
            QMessageBox.critical(self, "Error", "GP layer failed to load!")

        self.progress_bar.setValue(50)

        cbms_group.setExpanded(True)

        # Create or retrieve Base Layers group
        base_layers_group = root.findGroup("Base Layers")
        if base_layers_group is None:
            base_layers_group = root.addGroup("Base Layers")
        base_layers_group.setExpanded(False)

         # Load layers from the specified GeoPackage
        gpkg_files = [f for f in os.listdir(self.selected_folder) if f.endswith('.gpkg') and ('_maplayers' in f or '_2024maplayers' in f)]
        if gpkg_files:
            self.load_layers_from_geopackage(base_layers_group, os.path.join(self.selected_folder, gpkg_files[0]))  # Load the first matching file
        else:
            QMessageBox.warning(self, "Warning", "No GeoPackage files found with the specified patterns.")


        # Process Reference Data group
        reference_data_group = root.findGroup("SFGP_RefData")
        if reference_data_group is None:
            reference_data_group = root.addGroup("SFGP_RefData")
        reference_data_group.setExpanded(False)

        if hasattr(self, "refdata_folder") and self.refdata_folder:
            for file in os.listdir(self.refdata_folder):
                if file.endswith("_RefData.gpkg"):
                    gpkg_path = os.path.join(self.refdata_folder, file)
                    self.load_layers_from_geopackage(reference_data_group, gpkg_path)

        self.progress_bar.setValue(90)

         # Create a new group called "Value Relation"
        value_relation_group = root.addGroup("Value Relation")

        # Add the CSV layers to the "Value Relation" group
        for csv_layer in csv_layers:
            if csv_layer.isValid():
                project.addMapLayer(csv_layer, False)
                value_relation_group.addLayer(csv_layer)

        # Optionally, expand the group
        value_relation_group.setExpanded(False)

        # # Create or retrieve Value Relation group
        # value_relation_group = root.findGroup("Value Relation")
        # if value_relation_group is None:
        #     value_relation_group = root.addGroup("Value Relation")
        # value_relation_group.setExpanded(False)

        # # Process CSV layers if applicable
        # if hasattr(self, "load_layers_from_folder") and callable(self.load_layers_from_folder):
        #     csv_layers, _ = self.load_layers_from_folder(os.path.dirname(self.selected_folder))  # Use the directory of the selected file
        #     for csv_layer in csv_layers:
        #         if csv_layer.isValid():
        #             project.addMapLayer(csv_layer, False)
        #             value_relation_group.addLayer(csv_layer)

        # Load the raster layer from the selected file
        raster_file = self.select_rasterlayer.filePath()  # Get the selected raster file path
        if raster_file and os.path.exists(raster_file):
            layer_name = os.path.splitext(os.path.basename(raster_file))[0]
            raster_layer = QgsRasterLayer(raster_file, layer_name)
            if raster_layer.isValid():
                project.addMapLayer(raster_layer, False)  # Add to project without adding to the map
                root.addLayer(raster_layer)  # Add to the root, next to the base layers group
            else:
                QMessageBox.critical(self, "Error", "Raster layer failed to load!")
        else:
            QMessageBox.warning(self, "Warning", "Please select a valid raster file.")


        self.rename_layers() 

        self.progress_bar.setValue(100)
        QMessageBox.information(self, "Success", "Layers imported and organized successfully!")

        self.zoom_to_layer()
        

    def on_group_selection_changed(self, text):
        """Handle changes in the group selection dropdown"""
        if text == "Processing":
            self.processGroup.show()
            self.digiGroup.hide()
        elif text == "Digitize":
            self.processGroup.hide()
            self.digiGroup.show()

    def load_layers_from_geopackage(self, base_layers_group, gpkg_path, target_crs="EPSG:4326"):
            """Load layers from a GeoPackage into a specified group, reproject them, fix geometries (if needed), and save back."""
            conn = ogr.Open(gpkg_path)
            if conn is None:
                QMessageBox.critical(self, "Error", f"Failed to open GeoPackage: {gpkg_path}")
                return

            # Define target CRS
            target_crs = QgsCoordinateReferenceSystem(target_crs)

            # Iterate through layers in the GeoPackage
            for i in range(conn.GetLayerCount()):
                layer = conn.GetLayerByIndex(i)
                if not layer:
                    continue
                layer_name = layer.GetName()

                # Skip unwanted layers
                if 'layer_styles' in layer_name:
                    continue

                # Load the layer into QGIS
                qgis_layer = QgsVectorLayer(f"{gpkg_path}|layername={layer_name}", layer_name, 'ogr')
                if not qgis_layer.isValid():
                    QMessageBox.warning(self, "Load Error", f"Layer '{layer_name}' failed to load!")
                    continue

                # Check if the layer is already reprojected and has valid geometries
                if qgis_layer.crs() == target_crs:
                    invalid_features = [f for f in qgis_layer.getFeatures() if not f.geometry().isGeosValid()]
                    if not invalid_features:
                        QgsMessageLog.logMessage(
                            f"Layer '{layer_name}' is already reprojected and has valid geometries. Skipping.",
                            "Loader"
                        )
                        # Add the existing layer to the project
                        QgsProject.instance().addMapLayer(qgis_layer, False)
                        base_layers_group.addLayer(qgis_layer)
                        continue

                try:
                    # Reproject the layer if needed
                    reprojected_layer = qgis_layer
                    if qgis_layer.crs() != target_crs:
                        reprojected_layer = processing.run("native:reprojectlayer", {
                            'INPUT': qgis_layer,
                            'TARGET_CRS': target_crs,
                            'OUTPUT': 'memory:'
                        })['OUTPUT']
                        reprojected_layer.setName(layer_name)

                    # Fix geometries
                    fixed_layer = processing.run("native:fixgeometries", {
                        'INPUT': reprojected_layer,
                        'OUTPUT': 'memory:'
                    })['OUTPUT']
                    fixed_layer.setName(layer_name)

                    # Save the fixed and reprojected layer back to the GeoPackage
                    options = QgsVectorFileWriter.SaveVectorOptions()
                    options.layerName = layer_name
                    options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
                    options.driverName = "GPKG"

                    self.reprojected_layers = getattr(self, "reprojected_layers", [])

                    result = QgsVectorFileWriter.writeAsVectorFormatV3(
                        fixed_layer, gpkg_path, QgsCoordinateTransformContext(), options
                    )

                    if result[0] == QgsVectorFileWriter.NoError:
                        self.reprojected_layers.append(layer_name)  # Add the reprojected layer name to the list
                        QMessageBox.warning(
                                self,
                                "Warning",
                                f"Layer '{layer_name}' reprojected. If you detected this, please repeat Data Source Manager | Map generation to process and load again to reflect the changes on the reprojected layer.\n\nAll reprojected layers so far:\n" + "\n".join(self.reprojected_layers)
                        )
                        QgsMessageLog.logMessage(
                        f"Layer '{layer_name}' reprojected and fixed geometries saved to the GeoPackage.",
                        "GeoPackage Loader"
                    )
                    else:
                        QMessageBox.critical(
                                self,
                                "Save Error",
                                f"Error saving layer '{layer_name}': {result[1]}"
                        )

                    # Add the fixed layer to the project
                    QgsProject.instance().addMapLayer(fixed_layer, False)
                    base_layers_group.addLayer(fixed_layer)

                except Exception as e:
                    QMessageBox.critical(self, "Processing Error", f"Error processing layer '{layer_name}': {str(e)}")

            # Clean up connection
            del conn    


    def load_layers_from_folder(self, folder_path):
        csv_layers = []
        if not os.path.exists(folder_path):
            QMessageBox.critical(self, "Error", f"The selected directory does not exist: {folder_path}")
            return csv_layers, None

        for file in os.listdir(folder_path):
            file_path = os.path.join(folder_path, file)
            if file.endswith('.csv'):
                # Remove the file extension from the layer name
                layer_name = os.path.splitext(file)[0]
                layer = QgsVectorLayer(file_path, layer_name, "ogr")
                if layer.isValid():
                    csv_layers.append(layer)
        return csv_layers, None

    def rename_layers(self):
        """Rename layers based on specified suffixes."""
        # Define the suffixes to check for and their corresponding new names
        suffixes_to_rename = {
            'bgy': 'bgy',
            'brgy': 'bgy',
            'ea2024': 'ea',
            'ea': 'ea',
            'bldg': 'bldgpts',
            'bldg_points' : 'bldgpts',
            'landmark': 'landmark',
            'landmarks': 'landmark',
            'road': 'road',
            'road_updated': 'road',
            'updated_road' : 'road',
            'updated_river' : 'river',
            'river': 'river',
            'river_updated' : 'river',
            'block': 'block',
            'Block': 'block',
            'block2024': 'block',
        }

        # Get all layers in the project
        layers = QgsProject.instance().mapLayers().values()
        
        for layer in layers:
            layer_name = layer.name()
            renamed = False  # Flag to track if a renaming has occurred
            
            for suffix, new_suffix in suffixes_to_rename.items():
                if suffix in layer_name and not layer_name.endswith(new_suffix):
                    # Rename the layer to the new suffix
                    new_name = layer_name.split(suffix)[0] + new_suffix
                    layer.setName(new_name)
                    output = f"Layer renamed to: {new_name}"
                    renamed = True
                    break  # Break after renaming for this layer
            
            if not renamed:
                output = f"No renaming needed for layer: {layer_name}"
            
            print(output)

    #Digitize
    def run_digitize(self):
        """Load layers from the selected folder or GeoPackage file and apply QML styles."""
        # Get the selected GeoPackage file from QgsFileWidget
        self.selected_file = self.select_baselayer_2.filePath()  
        if not self.selected_file:
            QMessageBox.warning(self, "Warning", "Please select a Base Layer file first.")
            return

        # Validate the selected GeoPackage file
        if not os.path.exists(self.selected_file) or not self.selected_file.endswith('.gpkg'):
            QMessageBox.critical(self, "Error", "Selected file is invalid or not a GeoPackage.")
            return

        # Extract the folder path from the selected file
        self.selected_folder = os.path.dirname(self.selected_file)
        if not os.path.exists(self.selected_folder):
            QMessageBox.critical(self, "Error", "Selected folder does not exist.")
            return

        # Load layers from the selected folder
        sf_layer, gp_layer, csv_layers, _ = self.load_layers_from_folder2(self.selected_folder)
        self.sf_layer = sf_layer  # Store reference to SF layer
        self.gp_layer = gp_layer  # Store reference to GP layer

        # Get the current project instance
        project = QgsProject.instance()

        # Create a new group called "CBMS Form 8"
        root = project.layerTreeRoot()
        cbms_group = root.addGroup("CBMS Form 8")

        # Update progress bar
        self.progress_bar_2.setValue(10)  # Update progress

        # Add the SF and GP layers to the "CBMS Form 8" group if they are valid
        if sf_layer and sf_layer.isValid():
            project.addMapLayer(sf_layer, False)
            cbms_group.addLayer(sf_layer)
        else:
            QMessageBox.critical(self, "Error", "SF layer failed to load!")

        self.progress_bar_2.setValue(30)  # Update progress

        if gp_layer and gp_layer.isValid():
            project.addMapLayer(gp_layer, False)
            cbms_group.addLayer(gp_layer)
        else:
            QMessageBox.critical(self, "Error", "GP layer failed to load!")

        self.progress_bar_2.setValue(50)  # Update progress

        # Optionally, expand the group
        cbms_group.setExpanded(True)

        # Create a new group called "Base Layers"
        base_layers_group = root.addGroup("Base Layers")
        base_layers_group.setExpanded(False)

        # Load layers from the specified GeoPackage
        gpkg_files = [f for f in os.listdir(self.selected_folder) if f.endswith('.gpkg') and ('_maplayers' in f or '_2024maplayers' in f)]
        if gpkg_files:
            self.load_layers_from_geopackage2(base_layers_group, os.path.join(self.selected_folder, gpkg_files[0]))  # Load the first matching file
        else:
            QMessageBox.warning(self, "Warning", "No GeoPackage files found with the specified patterns.")


        # Load the raster layer from the selected file
        raster_file = self.select_rasterlayer_2.filePath()  # Get the selected raster file path
        if raster_file and os.path.exists(raster_file):
            # Remove the file extension from the base name
            layer_name = os.path.splitext(os.path.basename(raster_file))[0]

            # Create the raster layer with the modified name
            raster_layer = QgsRasterLayer(raster_file, layer_name)

            if raster_layer.isValid():
                project.addMapLayer(raster_layer, False)  # Add to project without adding to the map
                root.addLayer(raster_layer)  # Add to the root, next to the base layers group
            else:
                QMessageBox.critical(self, "Error", "Raster layer failed to load!")
        else:
            QMessageBox.warning(self, "Warning", "Please select a valid raster file.")

        self.progress_bar_2.setValue(90)  # Update progress

        # Create a new group called "Value Relation"
        value_relation_group = root.addGroup("Value Relation")

        # Add the CSV layers to the "Value Relation" group
        for csv_layer in csv_layers:
            if csv_layer.isValid():
                project.addMapLayer(csv_layer, False)
                value_relation_group.addLayer(csv_layer)

        # Optionally, expand the group
        value_relation_group.setExpanded(False)

        # Call the function to execute the renaming
        self.rename_layers() 

        # Final print to confirm structure
        self.progress_bar_2.setValue(100)  # Update progress
        QMessageBox.information(self, "Success", "Layers imported and organized successfully!")

        # Change data source for the loaded layers
        for layer in [self.sf_layer, self.gp_layer] + csv_layers:
            if layer and layer.isValid():
                # Update the data source to the new path
                new_source = layer.source()  # Get the current source
                layer.setDataSource(new_source, layer.name(), "ogr")
                layer.updateExtents()  # Update extents after changing the data source

        # Auto-save the QGIS project to the selected folder
        # project.write(os.path.join(self.selected_folder, "autosave_project.qgz"))  # Save the project

        self.zoom_to_layer()

    def load_csv(self, folder_path):
        csv_layers = []

        # Define the path to the 'files' subfolder within the plugin folder
        BASE_DIR = os.path.dirname(__file__)
        files_folder_path = os.path.join(BASE_DIR, "files")

        # Check if the 'files' folder exists
        if not os.path.exists(files_folder_path):
            QMessageBox.critical(self, "Error", f"The 'files' directory does not exist: {files_folder_path}")
            return  

        # Iterate through all files in the 'files' subfolder
        for file in os.listdir(files_folder_path):
            file_path = os.path.join(files_folder_path, file)
            
            if file.endswith(".csv"):
                # Load CSV layer with proper URI and UTF-8 encoding
                csv_layer = QgsVectorLayer(f"file:///{file_path}?delimiter=,&encoding=UTF-8", os.path.splitext(file)[0], "delimitedtext")  
                if csv_layer.isValid():
                    csv_layers.append(csv_layer)

                    # Copy the CSV file to the selected folder
                    new_csv_path = os.path.join(self.selected_folder, file)  
                    shutil.copy(file_path, new_csv_path)

                    print(f"Copied CSV file to: {new_csv_path}")  

        return csv_layers    


    def load_layers_from_geopackage2(self, base_layers_group, gpkg_path):
        """Load all layers from a GeoPackage into the specified group."""
        try:
            # Open the GeoPackage using OGR
            conn = ogr.Open(gpkg_path)
            if conn is None:
                QMessageBox.critical(self, "Error", f"Failed to open GeoPackage: {gpkg_path}")
                return

            layer_count = conn.GetLayerCount()
            if layer_count == 0:
                QMessageBox.warning(self, "Warning", "No layers found in the selected GeoPackage.")
                return

            # Iterate through all layers in the GeoPackage
            for i in range(layer_count):
                layer = conn.GetLayerByIndex(i)
                layer_name = layer.GetName()

                if 'layer_styles' in layer_name:
                    continue

                # Construct the QGIS layer
                qgis_layer = QgsVectorLayer(f"{gpkg_path}|layername={layer_name}", layer_name, 'ogr')

                if qgis_layer.isValid():
                    # Add layer to the QGIS project
                    QgsProject.instance().addMapLayer(qgis_layer, False)
                    base_layers_group.addLayer(qgis_layer)
                else:
                    print(f"Layer '{layer_name}' failed to load!")

            # QMessageBox.information(self, "Success", f"Successfully loaded {layer_count} layers from the GeoPackage.")

        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred while loading the GeoPackage: {str(e)}")

    #Digitize
    def load_layers_from_folder2(self, folder_path):
        sf_layer = None
        gp_layer = None
        csv_layers = []

        # Regular expression to match 5-digit identifiers
        # five_digit_pattern = re.compile(r'^\d{5}\.gpkg$')

        # Define the path to the 'files' subfolder within the plugin folder
        BASE_DIR = os.path.dirname(__file__)
        files_folder_path = os.path.join(BASE_DIR, "files\digitize")

        # Check if the 'files' folder exists
        if not os.path.exists(files_folder_path):
            QMessageBox.critical(self, "Error", f"The 'files' directory does not exist: {files_folder_path}")
            return  # Exit the function if the directory does not exist

        # Iterate through all files in the 'files' subfolder
        for file in os.listdir(files_folder_path):
            file_path = os.path.join(files_folder_path, file)
            if file.endswith(".shp"):
                if "_SF" in file:
                    sf_layer = QgsVectorLayer(file_path, os.path.splitext(file)[0], "ogr")
                    if not sf_layer.isValid():
                        print(f"Failed to load SF layer from: {file_path}")  # Log the error
                    # Copy related files for _SF
                    for ext in ['shp', 'cpg', 'dbf', 'shx', 'qmd', 'prj']:
                        original_file = os.path.splitext(file)[0] + '.' + ext
                        if os.path.exists(os.path.join(files_folder_path, original_file)):
                            gpkg_files = [f for f in os.listdir(folder_path) if f.endswith('.gpkg') and ('_maplayers' in f or '_2024maplayers' in f)]
                            gpkg_prefix = os.path.splitext(gpkg_files[0])[0][:5] if gpkg_files else ''
                            new_file_name = f"{gpkg_prefix}_SF.{ext}"  # New name for the copied file
                            new_file_path = os.path.join(self.selected_folder, new_file_name)
                            shutil.copy(os.path.join(files_folder_path, original_file), new_file_path)  # Copy the file
                            print(f"Copied and renamed {original_file} to {new_file_path}")  # Log the action
                    # Change data source to the new path (specifically the .shp file)
                    sf_shp_path = os.path.join(self.selected_folder, f"{gpkg_prefix}_SF.shp")  # Ensure this points to the .shp file
                    sf_layer.setDataSource(sf_shp_path, os.path.splitext(file)[0], "ogr")  
                    if not sf_layer.isValid():  
                        print(f"Failed to set data source for SF layer: {sf_shp_path}")  # Log the error
                elif "_GP" in file:
                    gp_layer = QgsVectorLayer(file_path, os.path.splitext(file)[0], "ogr")
                    if not gp_layer.isValid():
                        print(f"Failed to load GP layer from: {file_path}")  # Log the error
                    # Copy related files for _GP
                    for ext in ['shp', 'cpg', 'dbf', 'shx', 'qmd', 'prj']:
                        original_file = os.path.splitext(file)[0] + '.' + ext
                        if os.path.exists(os.path.join(files_folder_path, original_file)):
                            # Extract the 5-digit prefix from the corresponding gpkg file
                            gpkg_files = [f for f in os.listdir(folder_path) if f.endswith('.gpkg') and ('_maplayers' in f or '_2024maplayers' in f)]
                            gpkg_prefix = os.path.splitext(gpkg_files[0])[0][:5] if gpkg_files else ''  # Get the first 5 digits of the first gpkg file
                            new_file_name = f"{gpkg_prefix}_GP.{ext}"  # New name for the copied file
                            new_file_path = os.path.join(self.selected_folder, new_file_name)
                            shutil.copy(os.path.join(files_folder_path, original_file), new_file_path)
                            print(f"Copied and renamed {original_file} to {new_file_path}")  # Log the action
                    # Change data source to the new path (specifically the .shp file)
                    gp_shp_path = os.path.join(self.selected_folder, f"{gpkg_prefix}_GP.shp")  # Ensure this points to the .shp file
                    gp_layer.setDataSource(gp_shp_path, os.path.splitext(file)[0], "ogr")  
                    if not gp_layer.isValid():  
                        print(f"Failed to set data source for GP layer: {gp_shp_path}")  # Log the error
            elif file.endswith(".csv"):
                # Load CSV layer with proper URI and UTF-8 encoding
                csv_layer = QgsVectorLayer(f"file:///{file_path}?delimiter=,&encoding=UTF-8", os.path.splitext(file)[0], "delimitedtext")  # {{ edit_1 }}
                if csv_layer.isValid():
                    csv_layers.append(csv_layer)
                    # Copy the CSV file to the selected folder
                    new_csv_path = os.path.join(self.selected_folder, file)  # Define the new path
                    shutil.copy(file_path, new_csv_path)  # Copy the file

                    # Set the data source without encoding since it's already specified in the URI
                    csv_layer.setDataSource(new_csv_path, os.path.splitext(file)[0], "ogr")
                    print(f"Copied CSV file to: {new_csv_path}")  # Log the action

        return sf_layer, gp_layer, csv_layers, None  # Add a placeholder for the fourth value
import os
from qgis.core import QgsProject, QgsLayerTreeGroup
from qgis.PyQt.QtWidgets import QDialog, QMessageBox
from PyQt5.uic import loadUiType

# Function to filter layers based on selected geocode and suffix criteria
def filter_layers(layers, selected_geocode):
    first_8_digits = selected_geocode[:8]

    # Loop through each layer in the dictionary and apply relevant filters
    for layer_key, layer in layers.items():
        if layer is not None and layer.isValid():
            # Apply filters based on suffixes
            if layer.name().endswith('_bgy'):
                layer.setSubsetString(f"geocode = '{selected_geocode[:14]}'")
            elif layer.name().endswith(('_ea2024', '_ea')):
                layer.setSubsetString(f"geocode LIKE '{first_8_digits}%'")
            elif layer.name().endswith('_bldgpts'):
                layer.setSubsetString(f"geocode LIKE '{first_8_digits}%'")
            elif layer.name().endswith('_bldg_point'):
                layer.setSubsetString(f"geocode LIKE '{first_8_digits}%'")
            elif layer.name().endswith('_block'):
                layer.setSubsetString(f"geocode LIKE '{first_8_digits}%'")
            elif layer.name().endswith('GP_RefData'):
                        layer.setSubsetString(f"ref_id = '{first_8_digits}'")
            elif layer.name().endswith('SF_RefData'):
                        layer.setSubsetString(f"ref_id = '{first_8_digits}'")
            else:
                QMessageBox.warning(None, "Unsupported Layer", f"Layer '{layer.name()}' does not match any known suffixes.")
        else:
            QMessageBox.warning(None, "Layer Invalid", f"The layer '{layer_key}' is not valid or does not exist.")

# Function to reset filters on all layers
def reset_filters(layers):
    for layer_key, layer in layers.items():
        if layer is not None and layer.isValid():
            layer.setSubsetString("")  # Clear the filter
        else:
            QMessageBox.warning(None, "Layer Invalid", f"The layer '{layer_key}' is not valid or does not exist.")

DialogUi, _ = loadUiType(
    os.path.join(os.path.dirname(__file__), "../ui/geocode_filter.ui")
)

# Dialog class for the UI
class FilterLayerDialog(QDialog, DialogUi):
    def __init__(self, iface):
        super().__init__()
        self.setupUi(self)  # Load the UI from the .ui file
        self.setWindowTitle("Geocode Filter")

        # Connect UI elements to their respective functions
        self.select_baselayer.currentIndexChanged.connect(self.populate_layers_dropdown)
        self.select_bgy.currentIndexChanged.connect(self.populate_geocode_dropdown)
        self.run_filter.clicked.connect(self.run)
        self.reset_filter.clicked.connect(self.reset_filters)

        # Initialize variables
        self.layers = {}

        # Load groups on dialog initialization
        self.load_layer_groups()

    def load_layer_groups(self):
        # Populate the base layer dropdown with layer groups in the project
        self.select_baselayer.clear()
        root = QgsProject.instance().layerTreeRoot()
        groups = [child for child in root.children() if isinstance(child, QgsLayerTreeGroup)]
        for group in groups:
            self.select_baselayer.addItem(group.name(), group)

    def populate_layers_dropdown(self):
        # Get the selected group
        selected_group = self.select_baselayer.currentData()
        if not isinstance(selected_group, QgsLayerTreeGroup):
            return

        # Populate the BGY layer dropdown with layers in the selected group
        self.select_bgy.clear()
        layers = [layer for layer in selected_group.findLayers()]
        for layer in layers:
            self.select_bgy.addItem(layer.name(), layer.layer())

        # Clear geocode dropdown
        self.select_geocode.clear()

    def populate_geocode_dropdown(self):
        """Populate the geocode dropdown based on the selected layer."""
        selected_layer = self.select_bgy.currentData()
        self.select_geocode.clear()

        if selected_layer and selected_layer.name().endswith('_bgy'):
            # Get the index of 'geocode' and 'name' fields
            geocode_index = selected_layer.fields().indexOf('geocode')
            geocode_name_index = selected_layer.fields().indexOf('name')

            if geocode_index != -1 and geocode_name_index != -1:
                # Create a list of combined values in the format {geocode}_{name}
                formatted_values = [
                    f"{feature.attributes()[geocode_index]}_{feature.attributes()[geocode_name_index]}"
                    for feature in selected_layer.getFeatures()
                ]
                self.select_geocode.addItems(sorted(formatted_values))
            else:
                missing_fields = []
                if geocode_index == -1:
                    missing_fields.append('geocode')
                if geocode_name_index == -1:
                    missing_fields.append('name')
                QMessageBox.warning(None, "Missing Fields", f"Missing field(s): {', '.join(missing_fields)} in layer: {selected_layer.name()}")

    def run(self):
        # Get the selected layer and geocode
        selected_layer = self.select_bgy.currentData()
        selected_geocode = self.select_geocode.currentText()
        if not selected_layer or not selected_geocode:
            QMessageBox.warning(None, "Selection Error", "No layer or geocode selected.")
            return

        # Load predefined layer mapping based on known suffix patterns
        self.layers = {
            layer.name(): layer for layer in QgsProject.instance().mapLayers().values()
            if layer.name().endswith(('_bgy', '_bldg_point', '_ea2024','_block','_ea','_bldgpts','GP_RefData','SF_RefData'))
        }

        # Filter based on geocode for other layers while keeping the geocode dropdown intact
        filter_layers(self.layers, selected_geocode)
        self.progressBar.setValue(100)  # Complete

    def reset_filters(self):
        # Load predefined layer mapping based on known suffix patterns
        self.layers = {
            layer.name(): layer for layer in QgsProject.instance().mapLayers().values()
            if layer.name().endswith(('_bgy', '_bldg_point', '_ea2024','_block','_ea','_bldgpts','GP_RefData','SF_RefData'))
        }

        # Reset filters for all layers
        reset_filters(self.layers)
        self.select_geocode.clear()
        self.populate_geocode_dropdown()
        self.progressBar.setValue(0)  # Reset progress bar to 0

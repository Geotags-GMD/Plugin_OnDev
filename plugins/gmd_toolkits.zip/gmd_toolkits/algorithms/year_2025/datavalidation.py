"""
Name : 2. Data Validation model
Group : Map data processing - 2025
With QGIS : 32815
"""

from qgis.core import QgsProcessing
from qgis.core import QgsProcessingAlgorithm
from qgis.core import QgsProcessingMultiStepFeedback
from qgis.core import QgsProcessingParameterEnum
from qgis.core import QgsProcessingParameterVectorLayer
from qgis.core import QgsProcessingParameterFeatureSink
from qgis.core import QgsProcessingParameterDefinition
import processing


class DataValidation(QgsProcessingAlgorithm):

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterEnum('select_processing_module', 'Select Processing module', options=['1_SF_DATA_VALIDATION','2_GP_BC_DATA_VALIDATION'], allowMultiple=False, usesStaticStrings=False, defaultValue=None))
        param = QgsProcessingParameterVectorLayer('select_form_8_sf_or_gp_layer', 'Select Form 8 SF or GP Layer', types=[QgsProcessing.TypeVectorPoint], defaultValue=None)
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)
        param = QgsProcessingParameterVectorLayer('select_psgc', 'Select PSGC', types=[QgsProcessing.TypeVector], defaultValue=None)
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)
        self.addParameter(QgsProcessingParameterFeatureSink('SfCompletenessCheck', 'SF COMPLETENESS CHECK', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('SfDuplicateGeoid', 'SF DUPLICATE GEOID', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('SfInconsistentBsn', 'SF INCONSISTENT BSN', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('BcCompletenessCheck', 'BC COMPLETENESS CHECK', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('GpCompletenessCheck', 'GP COMPLETENESS CHECK', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('GpbcInconsistentBsn', 'GPBC INCONSISTENT BSN', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('Pppmmbbb_sf', 'pppmmbbb_SF', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, supportsAppend=True, defaultValue='TEMPORARY_OUTPUT'))
        self.addParameter(QgsProcessingParameterFeatureSink('Pppmmbbb_gp', 'pppmmbbb_GP', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, supportsAppend=True, defaultValue='TEMPORARY_OUTPUT'))

    def processAlgorithm(self, parameters, context, model_feedback):
        # Use a multi-step feedback, so that individual child algorithm progress reports are adjusted for the
        # overall progress through the model
        feedback = QgsProcessingMultiStepFeedback(76, model_feedback)
        results = {}
        outputs = {}

        # Map data processing
        alg_params = {
        }
        outputs['MapDataProcessing'] = processing.run('native:condition', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # GP delete other fields
        alg_params = {
            'FIELDS_MAPPING': [{'expression': '"BGY_NAME"','length': 100,'name': 'BGY_NAME','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CBMS_GEOID"','length': 26,'name': 'CBMS_GEOID','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"REG_NAME"','length': 100,'name': 'REG_NAME','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"PROV_NAME"','length': 100,'name': 'PROV_NAME','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"MUN_NAME"','length': 100,'name': 'MUN_NAME','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"X"','length': 25,'name': 'X','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"Y"','length': 25,'name': 'Y','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"DEV_PROJ"','length': 50,'name': 'DEV_PROJ','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"BLDGSTATUS"','length': 50,'name': 'BLDGSTATUS','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"STRUC_TYPE"','length': 50,'name': 'STRUC_TYPE','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"BSN"','length': 5,'name': 'BSN','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"GSN"','length': 5,'name': 'GSN','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"GP_NAME"','length': 250,'name': 'GP_NAME','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"GP_ADDRESS"','length': 250,'name': 'GP_ADDRESS','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"SECTOR"','length': 35,'name': 'SECTOR','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"STATUS"','length': 20,'name': 'STATUS','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"START_DATE"','length': 10,'name': 'START_DATE','precision': 0,'sub_type': 0,'type': 14,'type_name': 'date'},{'expression': '"COMPEX_DAT"','length': 10,'name': 'COMPEX_DAT','precision': 0,'sub_type': 0,'type': 14,'type_name': 'date'},{'expression': '"ALLBUDGET"','length': 50,'name': 'ALLBUDGET','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"GP_INSTYP"','length': 60,'name': 'GP_INSTYP','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"GP_INSFUND"','length': 60,'name': 'GP_INSFUND','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"REMARKS"','length': 250,'name': 'REMARKS','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"GEOCODE"','length': 26,'name': 'GEOCODE','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"OUT_NAM"','length': 32,'name': 'OUT_NAM','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"DOV"','length': 100,'name': 'DOV','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"BC_GEOID"','length': 26,'name': 'BC_GEOID','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"BCN"','length': 5,'name': 'BCN','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"BP-APRVD"','length': 30,'name': 'BP-APRVD','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"BP-NUMBER"','length': 50,'name': 'BP-NUMBER','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"BP-APPR"','length': 254,'name': 'BP-APPR','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"BP-APPDATE"','length': 10,'name': 'BP-APPDATE','precision': 0,'sub_type': 0,'type': 14,'type_name': 'date'},{'expression': '"REQ_BLDG"','length': 10,'name': 'REQ_BLDG','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"BC_ROLE"','length': 100,'name': 'BC_ROLE','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"BC_ROLE_OS"','length': 100,'name': 'BC_ROLE_OS','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"TYPE_BLDG"','length': 50,'name': 'TYPE_BLDG','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"TYPE_BLDGO"','length': 100,'name': 'TYPE_BLDGO','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"TYPE_OCCU"','length': 254,'name': 'TYPE_OCCU','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"TYPE_OCCUO"','length': 254,'name': 'TYPE_OCCUO','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CALLBACK"','length': 35,'name': 'CALLBACK','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CALL_CMPLT"','length': 35,'name': 'CALL_CMPLT','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CALLCMPLTO"','length': 254,'name': 'CALLCMPLTO','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'}],
            'INPUT': parameters['select_form_8_sf_or_gp_layer'],
            'OUTPUT': parameters['Pppmmbbb_gp']
        }
        outputs['GpDeleteOtherFields'] = processing.run('native:refactorfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Pppmmbbb_gp'] = outputs['GpDeleteOtherFields']['OUTPUT']

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # GP Check BSN for inconsistencies
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_BSN',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE \r\n  WHEN aggregate(\r\n    concat(substr("GEOCODE", 0, 5), \'_bldg_point\'),  -- Construct the layer name dynamically\r\n    \'count\', \r\n    "BSN", \r\n    intersects(buffer($geometry, 20), geometry(@parent)) \r\n    AND "BSN" = attribute(@parent, \'BSN\') \r\n    AND "BGY_GEO" = attribute(@parent, \'GEOCODE\')\r\n  ) > 0\r\n  THEN \'Match Found\'\r\n  ELSE \'No match\'\r\nEND\r\n',
            'INPUT': outputs['GpDeleteOtherFields']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['GpCheckBsnForInconsistencies'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # GP Update Barangay Name
        alg_params = {
            'EXISTANT': '"BGY_NAME"',
            'FILTRE': '',
            'FORMULE': 'attribute(get_feature(\'PSGC\',\'PSGC\',substr("CBMS_GEOID" ,0,8)),\'BARANGAY\')',
            'INPUT': outputs['GpDeleteOtherFields']['OUTPUT'],
            'PRECISION': 15,
            'TAILLE': 100,
            'TYPE': 0,  # String
        }
        outputs['GpUpdateBarangayName'] = processing.run('Networks:update_field', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # GP Update Province Name
        alg_params = {
            'EXISTANT': '"PROV_NAME"',
            'FILTRE': '',
            'FORMULE': 'attribute(get_feature(\'PSGC\',\'PSGC\',substr("CBMS_GEOID" ,0,8)),\'PROVINCE\')',
            'INPUT': outputs['GpDeleteOtherFields']['OUTPUT'],
            'PRECISION': 15,
            'TAILLE': 100,
            'TYPE': 0,  # String
        }
        outputs['GpUpdateProvinceName'] = processing.run('Networks:update_field', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            return {}

        # GP MDC Remarks
        alg_params = {
            'EXISTANT': '"MDC_Remarks"',
            'FILTRE': '',
            'FORMULE': ' ',
            'INPUT': outputs['GpDeleteOtherFields']['OUTPUT'],
            'PRECISION': 15,
            'TAILLE': 250,
            'TYPE': 0,  # String
        }
        outputs['GpMdcRemarks'] = processing.run('Networks:update_field', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        # GP Filter 39999 below
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'EX_BSN',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': '"BSN" < 39999',
            'INPUT': outputs['GpCheckBsnForInconsistencies']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['GpFilter39999Below'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}

        # GP Update City/Municipality Name
        alg_params = {
            'EXISTANT': '"MUN_NAME"',
            'FILTRE': '',
            'FORMULE': 'attribute(get_feature(\'PSGC\',\'PSGC\',substr("CBMS_GEOID" ,0,8)),\'CITY/MUNICIPALITY\')',
            'INPUT': outputs['GpDeleteOtherFields']['OUTPUT'],
            'PRECISION': 15,
            'TAILLE': 100,
            'TYPE': 0,  # String
        }
        outputs['GpUpdateCitymunicipalityName'] = processing.run('Networks:update_field', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(8)
        if feedback.isCanceled():
            return {}

        # GP MDP Status
        alg_params = {
            'EXISTANT': '"MDP_Status"',
            'FILTRE': '',
            'FORMULE': ' ',
            'INPUT': outputs['GpDeleteOtherFields']['OUTPUT'],
            'PRECISION': 15,
            'TAILLE': 150,
            'TYPE': 0,  # String
        }
        outputs['GpMdpStatus'] = processing.run('Networks:update_field', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(9)
        if feedback.isCanceled():
            return {}

        # SF delete other fields
        alg_params = {
            'FIELDS_MAPPING': [{'expression': '"CBMS_GEOID"','length': 26,'name': 'CBMS_GEOID','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"REG_NAME"','length': 100,'name': 'REG_NAME','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"PROV_NAME"','length': 100,'name': 'PROV_NAME','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"MUN_NAME"','length': 100,'name': 'MUN_NAME','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"BGY_NAME"','length': 100,'name': 'BGY_NAME','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"X"','length': 25,'name': 'X','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"Y"','length': 25,'name': 'Y','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"BLDGSTATUS"','length': 50,'name': 'BLDGSTATUS','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"STRUC_TYPE"','length': 50,'name': 'STRUC_TYPE','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"BSN"','length': 5,'name': 'BSN','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"FSN"','length': 5,'name': 'FSN','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"FAC_NAME"','length': 200,'name': 'FAC_NAME','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"FAC_ADDRES"','length': 200,'name': 'FAC_ADDRES','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"FAC_INSTYP"','length': 60,'name': 'FAC_INSTYP','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"SECTOR"','length': 40,'name': 'SECTOR','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"SPECTYPE"','length': 80,'name': 'SPECTYPE','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"OTHER_STYP"','length': 250,'name': 'OTHER_STYP','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"OTHER_USE"','length': 250,'name': 'OTHER_USE','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"REMARKS"','length': 250,'name': 'REMARKS','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"GEOCODE"','length': 26,'name': 'GEOCODE','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"DOV"','length': 100,'name': 'DOV','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"OUT_NAME"','length': 25,'name': 'OUT_NAME','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'}],
            'INPUT': parameters['select_form_8_sf_or_gp_layer'],
            'OUTPUT': parameters['Pppmmbbb_sf']
        }
        outputs['SfDeleteOtherFields'] = processing.run('native:refactorfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Pppmmbbb_sf'] = outputs['SfDeleteOtherFields']['OUTPUT']

        feedback.setCurrentStep(10)
        if feedback.isCanceled():
            return {}

        # (BCQ01) Check BC date of visit (BCQ01)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_BCQ01',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE \r\n    WHEN ("DEV_PROJ" IN (\'01_GOVERNMENT PROJECT\', \'02_PRIVATE CONSTRUCTION\') AND "DOV" IS NULL) \r\n    THEN \'Enter date of visit\'\r\n    ELSE NULL\r\nEND',
            'INPUT': outputs['GpDeleteOtherFields']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Bcq01CheckBcDateOfVisitBcq01'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(11)
        if feedback.isCanceled():
            return {}

        # (GPQ01) Check GP Bldg Status (GPQ01)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_GPQ01',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE\r\n  WHEN "DEV_PROJ" = \'01_GOVERNMENT PROJECT\' AND ("BLDGSTATUS" IS NULL OR "BLDGSTATUS" = \'\') THEN \'Enter Bldg Status\'\r\n  ELSE NULL\r\nEND\r\n',
            'INPUT': outputs['GpDeleteOtherFields']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Gpq01CheckGpBldgStatusGpq01'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(12)
        if feedback.isCanceled():
            return {}

        # GP MDP Remarks
        alg_params = {
            'EXISTANT': '"MDP_Remarks"',
            'FILTRE': '',
            'FORMULE': ' ',
            'INPUT': outputs['GpDeleteOtherFields']['OUTPUT'],
            'PRECISION': 15,
            'TAILLE': 250,
            'TYPE': 0,  # String
        }
        outputs['GpMdpRemarks'] = processing.run('Networks:update_field', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(13)
        if feedback.isCanceled():
            return {}

        # SF Update Barangay Name
        alg_params = {
            'EXISTANT': '"BGY_NAME"',
            'FILTRE': '',
            'FORMULE': 'attribute(get_feature(\'PSGC\',\'PSGC\',substr("CBMS_GEOID" ,0,8)),\'BARANGAY\')',
            'INPUT': outputs['SfDeleteOtherFields']['OUTPUT'],
            'PRECISION': 15,
            'TAILLE': 100,
            'TYPE': 0,  # String
        }
        outputs['SfUpdateBarangayName'] = processing.run('Networks:update_field', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(14)
        if feedback.isCanceled():
            return {}

        # SF Update Province Name
        alg_params = {
            'EXISTANT': '"PROV_NAME"',
            'FILTRE': '',
            'FORMULE': 'attribute(get_feature(\'PSGC\',\'PSGC\',substr("CBMS_GEOID" ,0,8)),\'PROVINCE\')',
            'INPUT': outputs['SfDeleteOtherFields']['OUTPUT'],
            'PRECISION': 15,
            'TAILLE': 100,
            'TYPE': 0,  # String
        }
        outputs['SfUpdateProvinceName'] = processing.run('Networks:update_field', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(15)
        if feedback.isCanceled():
            return {}

        # GP MDC Status
        alg_params = {
            'EXISTANT': '"MDC_Status"',
            'FILTRE': '',
            'FORMULE': ' ',
            'INPUT': outputs['GpDeleteOtherFields']['OUTPUT'],
            'PRECISION': 15,
            'TAILLE': 150,
            'TYPE': 0,  # String
        }
        outputs['GpMdcStatus'] = processing.run('Networks:update_field', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(16)
        if feedback.isCanceled():
            return {}

        # SF Update City/Municipality Name
        alg_params = {
            'EXISTANT': '"MUN_NAME"',
            'FILTRE': '',
            'FORMULE': 'attribute(get_feature(\'PSGC\',\'PSGC\',substr("CBMS_GEOID" ,0,8)),\'CITY/MUNICIPALITY\')',
            'INPUT': outputs['SfDeleteOtherFields']['OUTPUT'],
            'PRECISION': 15,
            'TAILLE': 100,
            'TYPE': 0,  # String
        }
        outputs['SfUpdateCitymunicipalityName'] = processing.run('Networks:update_field', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(17)
        if feedback.isCanceled():
            return {}

        # GP Update Region Name
        alg_params = {
            'EXISTANT': '"REG_NAME"',
            'FILTRE': '',
            'FORMULE': 'attribute(get_feature(\'PSGC\',\'PSGC\',substr("CBMS_GEOID" ,0,8)),\'REGION\')',
            'INPUT': outputs['GpDeleteOtherFields']['OUTPUT'],
            'PRECISION': 15,
            'TAILLE': 100,
            'TYPE': 0,  # String
        }
        outputs['GpUpdateRegionName'] = processing.run('Networks:update_field', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(18)
        if feedback.isCanceled():
            return {}

        # GP Extract 39999 below
        alg_params = {
            'EXPRESSION': '"EX_BSN" = 1',
            'INPUT': outputs['GpFilter39999Below']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['GpExtract39999Below'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(19)
        if feedback.isCanceled():
            return {}

        # (SFQ01) Check Facility name
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_SFQ01',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE\r\n    WHEN "FAC_NAME" = \'(-)\' THEN \'Input facility name\'\r\n    WHEN "FAC_NAME" IS NULL THEN \'Input facility name\'\r\n    ELSE NULL\r\nEND\r\n',
            'INPUT': outputs['SfDeleteOtherFields']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Sfq01CheckFacilityName'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(20)
        if feedback.isCanceled():
            return {}

        # SF Unique GeoID
        alg_params = {
            'FIELD_LENGTH': 100,
            'FIELD_NAME': 'SF_UNIQGEO',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'count("CBMS_GEOID",group_by:=CBMS_GEOID)',
            'INPUT': outputs['SfDeleteOtherFields']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SfUniqueGeoid'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(21)
        if feedback.isCanceled():
            return {}

        # (SFQ02) Check SF Address name
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_SFQ02',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE\r\n    WHEN "FAC_ADDRES" = \'(-)\' THEN \'Input address\'\r\n    WHEN "FAC_ADDRES" IS NULL THEN \'Input address\'\r\n    ELSE NULL\r\nEND\r\n',
            'INPUT': outputs['Sfq01CheckFacilityName']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Sfq02CheckSfAddressName'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(22)
        if feedback.isCanceled():
            return {}

        # SF MDP Remarks
        alg_params = {
            'EXISTANT': '"MDP_Remarks"',
            'FILTRE': '',
            'FORMULE': ' ',
            'INPUT': outputs['SfDeleteOtherFields']['OUTPUT'],
            'PRECISION': 15,
            'TAILLE': 250,
            'TYPE': 0,  # String
        }
        outputs['SfMdpRemarks'] = processing.run('Networks:update_field', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(23)
        if feedback.isCanceled():
            return {}

        # (GPQ02) Check GP Struct Type (GPQ02)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_GPQ02',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE\r\n  WHEN "DEV_PROJ" = \'01_GOVERNMENT PROJECT\' AND ("STRUC_TYPE" IS NULL OR "STRUC_TYPE" = \'\') THEN \'Enter Structure type\'\r\n  ELSE NULL\r\nEND\r\n',
            'INPUT': outputs['Gpq01CheckGpBldgStatusGpq01']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Gpq02CheckGpStructTypeGpq02'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(24)
        if feedback.isCanceled():
            return {}

        # SF Update Region Name
        alg_params = {
            'EXISTANT': '"REG_NAME"',
            'FILTRE': '',
            'FORMULE': 'attribute(get_feature(\'PSGC\',\'PSGC\',substr("CBMS_GEOID" ,0,8)),\'REGION\')',
            'INPUT': outputs['SfDeleteOtherFields']['OUTPUT'],
            'PRECISION': 15,
            'TAILLE': 100,
            'TYPE': 0,  # String
        }
        outputs['SfUpdateRegionName'] = processing.run('Networks:update_field', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(25)
        if feedback.isCanceled():
            return {}

        # SF MDC Remarks
        alg_params = {
            'EXISTANT': '"MDC_Remarks"',
            'FILTRE': '',
            'FORMULE': ' ',
            'INPUT': outputs['SfDeleteOtherFields']['OUTPUT'],
            'PRECISION': 15,
            'TAILLE': 250,
            'TYPE': 0,  # String
        }
        outputs['SfMdcRemarks'] = processing.run('Networks:update_field', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(26)
        if feedback.isCanceled():
            return {}

        # (BCQ02) Check BC BCN (BCQ02)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_BCQ02',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE\r\n  WHEN "DEV_PROJ" = \'02_PRIVATE CONSTRUCTION\' AND ("BCN" IS NULL OR "BCN" = \'\') THEN \'Append to last BCN\'\r\n  ELSE NULL\r\nEND\r\n',
            'INPUT': outputs['Bcq01CheckBcDateOfVisitBcq01']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Bcq02CheckBcBcnBcq02'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(27)
        if feedback.isCanceled():
            return {}

        # SF MDP Status
        alg_params = {
            'EXISTANT': '"MDP_Status"',
            'FILTRE': '',
            'FORMULE': ' ',
            'INPUT': outputs['SfDeleteOtherFields']['OUTPUT'],
            'PRECISION': 15,
            'TAILLE': 150,
            'TYPE': 0,  # String
        }
        outputs['SfMdpStatus'] = processing.run('Networks:update_field', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(28)
        if feedback.isCanceled():
            return {}

        # (SFQ03) Check Institution type
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_SFQ03',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'if("FAC_INSTYP" = \'(-)\'or NULL,\'Enter type of institution\',NULL)',
            'INPUT': outputs['Sfq02CheckSfAddressName']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Sfq03CheckInstitutionType'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(29)
        if feedback.isCanceled():
            return {}

        # SF Check BSN for inconsistencies
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_BSN',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE \r\n  WHEN aggregate(\r\n    concat(substr("GEOCODE", 0, 5), \'_bldg_point\'),  -- Construct the layer name dynamically\r\n    \'count\', \r\n    "BSN", \r\n    intersects(buffer($geometry, 20), geometry(@parent)) \r\n    AND "BSN" = attribute(@parent, \'BSN\') \r\n    AND "BGY_GEO" = attribute(@parent, \'GEOCODE\')\r\n  ) > 0\r\n  THEN \'Match Found\'\r\n  ELSE \'No match\'\r\nEND\r\n',
            'INPUT': outputs['SfDeleteOtherFields']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SfCheckBsnForInconsistencies'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(30)
        if feedback.isCanceled():
            return {}

        # SF MDC Status
        alg_params = {
            'EXISTANT': '"MDC_Status"',
            'FILTRE': '',
            'FORMULE': ' ',
            'INPUT': outputs['SfDeleteOtherFields']['OUTPUT'],
            'PRECISION': 15,
            'TAILLE': 150,
            'TYPE': 0,  # String
        }
        outputs['SfMdcStatus'] = processing.run('Networks:update_field', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(31)
        if feedback.isCanceled():
            return {}

        # GP Extract No match value
        alg_params = {
            'EXPRESSION': '"CK_BSN" = \'No match\'',
            'INPUT': outputs['GpExtract39999Below']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['GpExtractNoMatchValue'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(32)
        if feedback.isCanceled():
            return {}

        # (BCQ03) Check BC Type of building (BCQ03)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_BCQ03',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE \r\n    WHEN "REQ_BLDG" = \'01_YES\' OR "REQ_BLDG" IS NULL THEN \r\n        CASE \r\n            WHEN "TYPE_BLDG" IS NOT NULL THEN NULL\r\n            ELSE \'Enter type of building\'\r\n        END\r\n    ELSE \r\n        NULL\r\nEND\r\n',
            'INPUT': outputs['Bcq02CheckBcBcnBcq02']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Bcq03CheckBcTypeOfBuildingBcq03'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(33)
        if feedback.isCanceled():
            return {}

        # (GPQ03) Check GP GSN (GPQ03)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_GPQ03',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE\r\n  WHEN "DEV_PROJ" = \'01_GOVERNMENT PROJECT\' AND ("GSN" IS NULL OR "GSN" = \'\') THEN \'Append to last GSN\'\r\n  ELSE NULL\r\nEND\r\n',
            'INPUT': outputs['Gpq02CheckGpStructTypeGpq02']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Gpq03CheckGpGsnGpq03'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(34)
        if feedback.isCanceled():
            return {}

        # (GPQ04) Check Government project name (GPQ04)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_GPQ04',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE\r\n  WHEN "DEV_PROJ" = \'01_GOVERNMENT PROJECT\' AND ("GP_NAME" IS NULL OR "GP_NAME" = \'\') THEN \'Input GP name\'\r\n  ELSE NULL\r\nEND\r\n',
            'INPUT': outputs['Gpq03CheckGpGsnGpq03']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Gpq04CheckGovernmentProjectNameGpq04'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(35)
        if feedback.isCanceled():
            return {}

        # SF Extract Unique Value
        alg_params = {
            'EXPRESSION': '"SF_UNIQGEO" > 1',
            'INPUT': outputs['SfUniqueGeoid']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SfExtractUniqueValue'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(36)
        if feedback.isCanceled():
            return {}

        # (BCQ04) Check BC Type of occupancy (BCQ04)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_BCQ04',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE\r\n    WHEN "TYPE_BLDG" IS NOT NULL AND "TYPE_OCCU" IS NULL THEN \'Enter type of occupancy\'\r\n    ELSE NULL\r\nEND\r\n',
            'INPUT': outputs['Bcq03CheckBcTypeOfBuildingBcq03']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Bcq04CheckBcTypeOfOccupancyBcq04'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(37)
        if feedback.isCanceled():
            return {}

        # SF Duplicate GeoID
        alg_params = {
            'FIELDS_MAPPING': [{'expression': '"CBMS_GEOID"','length': 26,'name': 'CBMS_GEOID','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"SF_UNIQGEO"','length': 100,'name': 'SF_UNIQGEO','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'}],
            'INPUT': outputs['SfExtractUniqueValue']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SfDuplicateGeoid'] = processing.run('native:refactorfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(38)
        if feedback.isCanceled():
            return {}

        # SF Filter 30000 below
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'EX_BSN',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': '"BSN" < 30000',
            'INPUT': outputs['SfCheckBsnForInconsistencies']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SfFilter30000Below'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(39)
        if feedback.isCanceled():
            return {}

        # GP Check Inconsisten BSN Value
        alg_params = {
            'FIELDS_MAPPING': [{'expression': '"CBMS_GEOID"','length': 26,'name': 'CBMS_GEOID','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"BSN"','length': 5,'name': 'BSN','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_BSN"','length': 50,'name': 'CK_BSN','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'}],
            'INPUT': outputs['GpExtractNoMatchValue']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['GpCheckInconsistenBsnValue'] = processing.run('native:refactorfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(40)
        if feedback.isCanceled():
            return {}

        # (SFQ04) Check Sector type
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_SFQ04',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'if("SECTOR" = \'(-)\'or NULL,\'Enter Sector type\',NULL)',
            'INPUT': outputs['Sfq03CheckInstitutionType']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Sfq04CheckSectorType'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(41)
        if feedback.isCanceled():
            return {}

        # (GPQ05) Check GP Address name (GPQ05)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_GPQ05',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE\r\n  WHEN "DEV_PROJ" = \'01_GOVERNMENT PROJECT\' AND ("GP_ADDRESS" IS NULL OR "GP_ADDRESS" = \'\') THEN \'Input GP address\'\r\n  ELSE NULL\r\nEND\r\n',
            'INPUT': outputs['Gpq04CheckGovernmentProjectNameGpq04']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Gpq05CheckGpAddressNameGpq05'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(42)
        if feedback.isCanceled():
            return {}

        # (GPQ06) Check GP Sector type (GPQ06)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_GPQ06',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE\r\n  WHEN "DEV_PROJ" = \'01_GOVERNMENT PROJECT\' AND ("SECTOR" IS NULL OR "SECTOR" = \'\') THEN \'Enter GP Sector type\'\r\n  ELSE NULL\r\nEND\r\n',
            'INPUT': outputs['Gpq05CheckGpAddressNameGpq05']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Gpq06CheckGpSectorTypeGpq06'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(43)
        if feedback.isCanceled():
            return {}

        # SF GeoID
        alg_params = {
            'COLUMN_NAME': 'SF_UNIQGEO',
            'INPUT': outputs['SfDuplicateGeoid']['OUTPUT'],
            'OUTPUT': parameters['SfDuplicateGeoid']
        }
        outputs['SfGeoid'] = processing.run('gmd_toolkits:outputcheck', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['SfDuplicateGeoid'] = outputs['SfGeoid']['OUTPUT']

        feedback.setCurrentStep(44)
        if feedback.isCanceled():
            return {}

        # (BCQ05) Check BC specific type of occupancy (BCQ05)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_BCQ05',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE\r\n    WHEN "TYPE_OCCU" LIKE \'%_Other%\' AND "TYPE_OCCUO" IS NULL\r\n    THEN \'Input specific structure\'\r\n    ELSE NULL\r\nEND',
            'INPUT': outputs['Bcq04CheckBcTypeOfOccupancyBcq04']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Bcq05CheckBcSpecificTypeOfOccupancyBcq05'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(45)
        if feedback.isCanceled():
            return {}

        # SF Extract 3000 below
        alg_params = {
            'EXPRESSION': '"EX_BSN" = 1',
            'INPUT': outputs['SfFilter30000Below']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SfExtract3000Below'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(46)
        if feedback.isCanceled():
            return {}

        # GP Check for Inconsistent BSN
        alg_params = {
            'COLUMN_NAME': 'CK_BSN',
            'INPUT': outputs['GpCheckInconsistenBsnValue']['OUTPUT'],
            'OUTPUT': parameters['GpbcInconsistentBsn']
        }
        outputs['GpCheckForInconsistentBsn'] = processing.run('gmd_toolkits:outputcheck', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['GpbcInconsistentBsn'] = outputs['GpCheckForInconsistentBsn']['OUTPUT']

        feedback.setCurrentStep(47)
        if feedback.isCanceled():
            return {}

        # (BCQ06) Check BC BP number (BCQ06)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_BCQ06',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE \r\n    WHEN "BP-APRVD" = \'01_YES\' AND "BP-NUMBER" IS NOT NULL THEN NULL\r\n    WHEN "BP-APRVD" = \'01_YES\' AND "BP-NUMBER" IS NULL THEN \'Input building permit number\'\r\n    ELSE NULL\r\nEND',
            'INPUT': outputs['Bcq05CheckBcSpecificTypeOfOccupancyBcq05']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Bcq06CheckBcBpNumberBcq06'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(48)
        if feedback.isCanceled():
            return {}

        # (GPQ07) Check GP Status (GPQ07)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_GPQ07',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE\r\n  WHEN "DEV_PROJ" = \'01_GOVERNMENT PROJECT\' AND ("STATUS" IS NULL OR "STATUS" = \'\') THEN \'Enter GP Status\'\r\n  ELSE NULL\r\nEND\r\n',
            'INPUT': outputs['Gpq06CheckGpSectorTypeGpq06']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Gpq07CheckGpStatusGpq07'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(49)
        if feedback.isCanceled():
            return {}

        # (BCQ07) Check BC BP number Approved date (BCQ07)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_BCQ07',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE \r\n  WHEN "BP-NUMBER" IS NOT NULL AND "BP-APPDATE" IS NULL THEN \'Enter approved date\'\r\n  ELSE NULL\r\nEND',
            'INPUT': outputs['Bcq06CheckBcBpNumberBcq06']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Bcq07CheckBcBpNumberApprovedDateBcq07'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(50)
        if feedback.isCanceled():
            return {}

        # (SFQ05) Check Specific type
        alg_params = {
            'FIELD_LENGTH': 1,
            'FIELD_NAME': 'CK_SFQ05',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'if("SPECTYPE" = \'(-)\'or NULL,\'Enter Specific type\',NULL)',
            'INPUT': outputs['Sfq04CheckSectorType']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Sfq05CheckSpecificType'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(51)
        if feedback.isCanceled():
            return {}

        # (GPQ08) Check GP Start date name (GPQ08)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_GPQ08',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE \r\n    WHEN ("DEV_PROJ" IN (\'01_GOVERNMENT PROJECT\', \'02_PRIVATE CONSTRUCTION\') AND "START_DATE" IS NULL) \r\n    THEN \'Enter Start date of construction\'\r\n    ELSE NULL\r\nEND',
            'INPUT': outputs['Gpq07CheckGpStatusGpq07']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Gpq08CheckGpStartDateNameGpq08'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(52)
        if feedback.isCanceled():
            return {}

        # SF Extract No match value
        alg_params = {
            'EXPRESSION': '"CK_BSN" = \'No match\'',
            'INPUT': outputs['SfExtract3000Below']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SfExtractNoMatchValue'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(53)
        if feedback.isCanceled():
            return {}

        # SF Check Inconsisten BSN Value
        alg_params = {
            'FIELDS_MAPPING': [{'expression': '"CBMS_GEOID"','length': 26,'name': 'CBMS_GEOID','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"BSN"','length': 5,'name': 'BSN','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_BSN"','length': 50,'name': 'CK_BSN','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'}],
            'INPUT': outputs['SfExtractNoMatchValue']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SfCheckInconsistenBsnValue'] = processing.run('native:refactorfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(54)
        if feedback.isCanceled():
            return {}

        # (BCQ08) Check BC BP reason (BCQ08)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_BCQ08',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE\r\n  WHEN "BP-APRVD" = \'02_NO\' AND "BP-APPR" IS NOT NULL THEN NULL\r\n  WHEN "BP-APRVD" <> \'02_NO\' THEN \'Enter reason for no BP\'\r\n  ELSE NULL\r\nEND\r\n',
            'INPUT': outputs['Bcq07CheckBcBpNumberApprovedDateBcq07']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Bcq08CheckBcBpReasonBcq08'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(55)
        if feedback.isCanceled():
            return {}

        # (SFQ06) Check Other Specific type
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_SFQ06',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE \r\n    WHEN "SPECTYPE" = \'0199_OTHERS, PLEASE SPECIFY\' AND "OTHER_STYP" IS NULL \r\n    THEN \'Input other specific type\' \r\n\t    WHEN "SPECTYPE" = \'0299_OTHERS, PLEASE SPECIFY\' AND "OTHER_STYP" IS NULL \r\n    THEN \'Input other specific type\' \r\n\t    WHEN "SPECTYPE" = \'0399_OTHERS, PLEASE SPECIFY\' AND "OTHER_STYP" IS NULL \r\n    THEN \'Input other specific type\' \r\n\t    WHEN "SPECTYPE" = \'0499_OTHERS, PLEASE SPECIFY\' AND "OTHER_STYP" IS NULL \r\n    THEN \'Input other specific type\' \r\n\t    WHEN "SPECTYPE" = \'0599_OTHERS, PLEASE SPECIFY\' AND "OTHER_STYP" IS NULL \r\n    THEN \'Input other specific type\' \r\n\t    WHEN "SPECTYPE" = \'0699_OTHERS, PLEASE SPECIFY\' AND "OTHER_STYP" IS NULL \r\n    THEN \'Input other specific type\' \r\n\t    WHEN "SPECTYPE" = \'0799_OTHERS, PLEASE SPECIFY\' AND "OTHER_STYP" IS NULL \r\n    THEN \'Input other specific type\' \r\n\t    WHEN "SPECTYPE" = \'0899_OTHERS, PLEASE SPECIFY\' AND "OTHER_STYP" IS NULL \r\n    THEN \'Input other specific type\' \r\n\t    WHEN "SPECTYPE" = \'0999_OTHERS, PLEASE SPECIFY\' AND "OTHER_STYP" IS NULL \r\n    THEN \'Input other specific type\' \r\n    ELSE NULL \r\nEND\r\n',
            'INPUT': outputs['Sfq05CheckSpecificType']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Sfq06CheckOtherSpecificType'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(56)
        if feedback.isCanceled():
            return {}

        # SF Check for Inconsistent BSN
        alg_params = {
            'COLUMN_NAME': 'CK_BSN',
            'INPUT': outputs['SfCheckInconsistenBsnValue']['OUTPUT'],
            'OUTPUT': parameters['SfInconsistentBsn']
        }
        outputs['SfCheckForInconsistentBsn'] = processing.run('gmd_toolkits:outputcheck', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['SfInconsistentBsn'] = outputs['SfCheckForInconsistentBsn']['OUTPUT']

        feedback.setCurrentStep(57)
        if feedback.isCanceled():
            return {}

        # (GPQ09) Check GP ex/comp date name (GPQ09)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_GPQ09',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE \r\n    WHEN ("DEV_PROJ" IN (\'01_GOVERNMENT PROJECT\', \'02_PRIVATE CONSTRUCTION\') AND "COMPEX_DAT" IS NULL) \r\n    THEN \'Enter date of completion\'\r\n    ELSE NULL\r\nEND\r\n',
            'INPUT': outputs['Gpq08CheckGpStartDateNameGpq08']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Gpq09CheckGpExcompDateNameGpq09'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(58)
        if feedback.isCanceled():
            return {}

        # (BCQ09) Check BC Role (BCQ09)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_BCQ09',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE\r\n    WHEN "DEV_PROJ" = \'01_GOVERNMENT PROJECT\' AND "REQ_BLDG" = \'01_YES\' AND "BC_ROLE" IS NULL\r\n        THEN \'Enter respondent role\'\r\n    WHEN "DEV_PROJ" = \'01_GOVERNMENT PROJECT\' AND "REQ_BLDG" = \'02_NO\' AND "BC_ROLE" IS NOT NULL\r\n        THEN NULL\r\n    WHEN "DEV_PROJ" = \'02_PRIVATE CONSTRUCTION\' AND "REQ_BLDG" IS NULL AND "BC_ROLE" IS NULL\r\n        THEN \'Enter respondent role\'\r\n    ELSE NULL\r\nEND\r\n',
            'INPUT': outputs['Bcq08CheckBcBpReasonBcq08']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Bcq09CheckBcRoleBcq09'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(59)
        if feedback.isCanceled():
            return {}

        # SF Check for identified value
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_IDVALUE',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE \r\n  WHEN "CK_SFQ01" IS NULL AND \r\n       "CK_SFQ02" IS NULL AND \r\n       "CK_SFQ03" IS NULL AND \r\n       "CK_SFQ04" IS NULL AND \r\n       "CK_SFQ05" IS NULL AND \r\n       "CK_SFQ06" IS NULL \r\n  THEN NULL\r\n  ELSE 1\r\nEND\r\n',
            'INPUT': outputs['Sfq06CheckOtherSpecificType']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SfCheckForIdentifiedValue'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(60)
        if feedback.isCanceled():
            return {}

        # (GPQ10) Check GP Budget name (GPQ10)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_GPQ10',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE\r\n  WHEN "DEV_PROJ" = \'01_GOVERNMENT PROJECT\' AND ("ALLBUDGET" IS NULL OR "ALLBUDGET" = \'\') THEN \'Input total amount of construction\'\r\n  ELSE NULL\r\nEND\r\n',
            'INPUT': outputs['Gpq09CheckGpExcompDateNameGpq09']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Gpq10CheckGpBudgetNameGpq10'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(61)
        if feedback.isCanceled():
            return {}

        # SF Extract IDvalue
        alg_params = {
            'EXPRESSION': '"CK_IDVALUE" = 1',
            'INPUT': outputs['SfCheckForIdentifiedValue']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SfExtractIdvalue'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(62)
        if feedback.isCanceled():
            return {}

        # (BCQ10) Check BC Role Other Specify (BCQ10)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_BCQ10',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE \r\n    WHEN "REQ_BLDG" IN (\'01_YES\', NULL) AND "BC_ROLE" IS NULL THEN \'Input respondent role\'\r\n    WHEN "REQ_BLDG" = \'02_NO\' AND "BC_ROLE" IS NOT NULL THEN \'Delete entry\'\r\n    ELSE NULL\r\nEND\r\n',
            'INPUT': outputs['Bcq09CheckBcRoleBcq09']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Bcq10CheckBcRoleOtherSpecifyBcq10'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(63)
        if feedback.isCanceled():
            return {}

        # (GPQ11) Check GP Institutional name (GPQ11)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_GPQ11',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE\r\n  WHEN "DEV_PROJ" = \'01_GOVERNMENT PROJECT\' AND ("GP_INSTYP" IS NULL OR "GP_INSTYP" = \'\') THEN \'Enter GP Type of Institution\'\r\n  ELSE NULL\r\nEND\r\n',
            'INPUT': outputs['Gpq10CheckGpBudgetNameGpq10']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Gpq11CheckGpInstitutionalNameGpq11'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(64)
        if feedback.isCanceled():
            return {}

        # (BCQ11) Check BC Callback (BCQ11)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_BCQ11',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE\r\n    WHEN "CALLBACK" = \'02_NOT YET COMPLETED (CALLBACK)\' THEN \'Verify with Team Supervisor\'\r\n    ELSE NULL\r\nEND',
            'INPUT': outputs['Bcq10CheckBcRoleOtherSpecifyBcq10']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Bcq11CheckBcCallbackBcq11'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(65)
        if feedback.isCanceled():
            return {}

        # SF Completness Check
        alg_params = {
            'FIELDS_MAPPING': [{'expression': '"CBMS_GEOID"','length': 26,'name': 'SF_GEOID','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"X"','length': 25,'name': 'X','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"Y"','length': 25,'name': 'Y','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"FAC_NAME"','length': 200,'name': 'FAC_NAME','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"FAC_ADDRES"','length': 200,'name': 'FAC_ADDRES','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"SPECTYPE"','length': 80,'name': 'SPECTYPE','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"OTHER_STYP"','length': 250,'name': 'OTHER_STYP','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"GEOCODE"','length': 26,'name': 'GEOCODE','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"MDP_Status"','length': 150,'name': 'MDP_Status','precision': 15,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_SFQ01"','length': 50,'name': 'CK_SFQ01','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_SFQ02"','length': 50,'name': 'CK_SFQ02','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_SFQ03"','length': 50,'name': 'CK_SFQ03','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_SFQ04"','length': 50,'name': 'CK_SFQ04','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_SFQ05"','length': 1,'name': 'CK_SFQ05','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_SFQ06"','length': 50,'name': 'CK_SFQ06','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'}],
            'INPUT': outputs['SfExtractIdvalue']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SfCompletnessCheck'] = processing.run('native:refactorfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(66)
        if feedback.isCanceled():
            return {}

        # (GPQ12) Check GP Funding Institution (GPQ12)
        alg_params = {
            'FIELD_LENGTH': 50,
            'FIELD_NAME': 'CK_GPQ12',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE\r\n  WHEN "DEV_PROJ" = \'01_GOVERNMENT PROJECT\' AND ("GP_INSFUND" IS NULL OR "GP_INSFUND" = \'\') THEN \'Enter GP funding institution\'\r\n  ELSE NULL\r\nEND',
            'INPUT': outputs['Gpq11CheckGpInstitutionalNameGpq11']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Gpq12CheckGpFundingInstitutionGpq12'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(67)
        if feedback.isCanceled():
            return {}

        # SF CCK
        alg_params = {
            'COLUMN_NAME': 'SF_GEOID',
            'INPUT': outputs['SfCompletnessCheck']['OUTPUT'],
            'OUTPUT': parameters['SfCompletenessCheck']
        }
        outputs['SfCck'] = processing.run('gmd_toolkits:outputcheck', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['SfCompletenessCheck'] = outputs['SfCck']['OUTPUT']

        feedback.setCurrentStep(68)
        if feedback.isCanceled():
            return {}

        # BC Check BC only
        alg_params = {
            'FIELD_LENGTH': 1,
            'FIELD_NAME': 'BCVALUE',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE\r\n  WHEN "BC_GEOID" IS NOT NULL AND ("REQ_BLDG" = \'01_YES\' OR "REQ_BLDG" IS NULL) AND\r\n       ("CK_BCQ01" IS NOT NULL OR "CK_BCQ02" IS NOT NULL OR "CK_BCQ03" IS NOT NULL OR "CK_BCQ04" IS NOT NULL OR\r\n        "CK_BCQ05" IS NOT NULL OR "CK_BCQ06" IS NOT NULL OR "CK_BCQ07" IS NOT NULL OR "CK_BCQ08" IS NOT NULL OR\r\n        "CK_BCQ09" IS NOT NULL OR "CK_BCQ10" IS NOT NULL OR "CK_BCQ11" IS NOT NULL)\r\n  THEN 1\r\n  ELSE \'\'\r\nEND\r\n',
            'INPUT': outputs['Bcq11CheckBcCallbackBcq11']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['BcCheckBcOnly'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(69)
        if feedback.isCanceled():
            return {}

        # BC Extract BC
        alg_params = {
            'EXPRESSION': '"BCVALUE" = 1',
            'INPUT': outputs['BcCheckBcOnly']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['BcExtractBc'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(70)
        if feedback.isCanceled():
            return {}

        # GP Check GP only
        alg_params = {
            'FIELD_LENGTH': 1,
            'FIELD_NAME': 'GPVALUE',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Text (string)
            'FORMULA': 'CASE \r\n    WHEN "CBMS_GEOID" IS NOT NULL AND \r\n         ("CK_GPQ01" IS NOT NULL OR "CK_GPQ02" IS NOT NULL OR "CK_GPQ03" IS NOT NULL OR \r\n          "CK_GPQ04" IS NOT NULL OR "CK_GPQ05" IS NOT NULL OR "CK_GPQ06" IS NOT NULL OR \r\n          "CK_GPQ07" IS NOT NULL OR "CK_GPQ08" IS NOT NULL OR "CK_GPQ09" IS NOT NULL OR \r\n          "CK_GPQ10" IS NOT NULL OR "CK_GPQ11" IS NOT NULL OR "CK_GPQ12" IS NOT NULL) \r\n    THEN 1\r\n    \r\n    WHEN "CBMS_GEOID" IS NOT NULL AND \r\n         ("CK_GPQ01" IS NULL AND "CK_GPQ02" IS NULL AND "CK_GPQ03" IS NULL AND \r\n          "CK_GPQ04" IS NULL AND "CK_GPQ05" IS NULL AND "CK_GPQ06" IS NULL AND \r\n          "CK_GPQ07" IS NULL AND "CK_GPQ08" IS NULL AND "CK_GPQ09" IS NULL AND \r\n          "CK_GPQ10" IS NULL AND "CK_GPQ11" IS NULL AND "CK_GPQ12" IS NULL) \r\n    THEN \'\'\r\n    \r\n    ELSE \'\'\r\nEND',
            'INPUT': outputs['Gpq12CheckGpFundingInstitutionGpq12']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['GpCheckGpOnly'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(71)
        if feedback.isCanceled():
            return {}

        # GP Extract GP
        alg_params = {
            'EXPRESSION': '"GPVALUE" = 1',
            'INPUT': outputs['GpCheckGpOnly']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['GpExtractGp'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(72)
        if feedback.isCanceled():
            return {}

        # BC Completeness check ouput
        alg_params = {
            'FIELDS_MAPPING': [{'expression': '"BC_GEOID"','length': 26,'name': 'BC_GEOID','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"BCN"','length': 5,'name': 'BCN','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"X"','length': 25,'name': 'X','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"Y"','length': 25,'name': 'Y','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_BCQ01"','length': 50,'name': 'CK_BCQ01','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_BCQ02"','length': 50,'name': 'CK_BCQ02','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_BCQ03"','length': 50,'name': 'CK_BCQ03','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_BCQ04"','length': 50,'name': 'CK_BCQ04','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_BCQ05"','length': 50,'name': 'CK_BCQ05','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_BCQ06"','length': 50,'name': 'CK_BCQ06','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_BCQ07"','length': 50,'name': 'CK_BCQ07','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_BCQ08"','length': 50,'name': 'CK_BCQ08','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_BCQ09"','length': 50,'name': 'CK_BCQ09','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_BCQ10"','length': 50,'name': 'CK_BCQ10','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_BCQ11"','length': 50,'name': 'CK_BCQ11','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'}],
            'INPUT': outputs['BcExtractBc']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['BcCompletenessCheckOuput'] = processing.run('native:refactorfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(73)
        if feedback.isCanceled():
            return {}

        # GP Completeness check ouput
        alg_params = {
            'FIELDS_MAPPING': [{'expression': '"CBMS_GEOID"','length': 26,'name': 'GP_GEOID','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"X"','length': 25,'name': 'X','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"Y"','length': 25,'name': 'Y','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"GP_NAME"','length': 250,'name': 'GP_NAME','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"GP_ADDRESS"','length': 250,'name': 'GP_ADDRESS','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"SECTOR"','length': 35,'name': 'SECTOR','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_GPQ01"','length': 50,'name': 'CK_GPQ01','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_GPQ02"','length': 50,'name': 'CK_GPQ02','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_GPQ03"','length': 50,'name': 'CK_GPQ03','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_GPQ04"','length': 50,'name': 'CK_GPQ04','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_GPQ05"','length': 50,'name': 'CK_GPQ05','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_GPQ06"','length': 50,'name': 'CK_GPQ06','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_GPQ07"','length': 50,'name': 'CK_GPQ07','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_GPQ08"','length': 50,'name': 'CK_GPQ08','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_GPQ09"','length': 50,'name': 'CK_GPQ09','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_GPQ10"','length': 50,'name': 'CK_GPQ10','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_GPQ11"','length': 50,'name': 'CK_GPQ11','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},{'expression': '"CK_GPQ12"','length': 50,'name': 'CK_GPQ12','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'}],
            'INPUT': outputs['GpExtractGp']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['GpCompletenessCheckOuput'] = processing.run('native:refactorfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(74)
        if feedback.isCanceled():
            return {}

        # BC CCK
        alg_params = {
            'COLUMN_NAME': 'BC_GEOID',
            'INPUT': outputs['BcCompletenessCheckOuput']['OUTPUT'],
            'OUTPUT': parameters['BcCompletenessCheck']
        }
        outputs['BcCck'] = processing.run('gmd_toolkits:outputcheck', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['BcCompletenessCheck'] = outputs['BcCck']['OUTPUT']

        feedback.setCurrentStep(75)
        if feedback.isCanceled():
            return {}

        # GP CCK
        alg_params = {
            'COLUMN_NAME': 'GP_GEOID',
            'INPUT': outputs['GpCompletenessCheckOuput']['OUTPUT'],
            'OUTPUT': parameters['GpCompletenessCheck']
        }
        outputs['GpCck'] = processing.run('gmd_toolkits:outputcheck', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['GpCompletenessCheck'] = outputs['GpCck']['OUTPUT']
        return results

    def name(self):
        return '2. Data Validation model'

    def displayName(self):
        return '2. Data Validation model'

    def group(self):
        return '2025 Processing'

    def groupId(self):
        return '2025_processing'

    def shortHelpString(self):
        return """<html><body><p><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">
<html><head><meta name="qrichtext" content="1" /><style type="text/css">
p, li { white-space: pre-wrap; }
</style></head><body style=" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;">
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">This  model is designed to streamline data validation by ensuring the <span style=" font-weight:600;">co</span>mp<span style=" font-weight:600;">le</span>teness and consistency of attribute information. It automatically updates location codes based on the latest <span style=" font-weight:600;">Philippine Standard Geographic Code (PSGC)</span>, reducing manual errors and ensuring alignment with official records. The model also identifies inconsistencies in <span style=" font-weight:600;">Building Serial Numbers (BSN)</span> across <span style=" font-weight:600;">Service Facilities (SF), Government Projects (GP), and Building Constructions (BC)</span> layers, helping maintain data integrity. Additionally, it detects duplicate <span style=" font-weight:600;">GeoID entries</span> within the <span style=" font-weight:600;">SF layer</span>, preventing redundancy and enhancing spatial data accuracy. This automated validation pro<span style=" font-weight:600;">c</span>ess impr<span style=" font-weight:600;">o</span>ves data re<span style=" font-weight:600;">l</span>iability and <span style=" font-weight:600;">e</span>fficiency in geospatial analysis.</p></body></html></p>
<h2>Input parameters</h2>
<h3>Select Processing module</h3>
<p>Select the Processing mode (Service Facility or Government Project)</p>
<h3>Select Form 8 SF or GP Layer</h3>
<p>Select what type of Form 8 will undergo processing (Service Facility or Government Project/Building Construction)</p>
<h3>Select PSGC</h3>
<p>Select Philippine Standard Geographic Code</p>
<h2>Examples</h2>
<p><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">
<html><head><meta name="qrichtext" content="1" /><style type="text/css">
p, li { white-space: pre-wrap; }
</style></head><body style=" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;">
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" color:#ffffff; background-color:#ffffff;">CPA</span></p></body></html></p><br><p align="right">Algorithm author: GMD</p><p align="right">Help author: Geospatial Management Division</p></body></html>"""

    def createInstance(self):
        return DataValidation()

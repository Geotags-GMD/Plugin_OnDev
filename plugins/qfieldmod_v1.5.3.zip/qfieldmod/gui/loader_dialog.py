from qgis.core import QgsProject, QgsVectorLayer, QgsRasterLayer,QgsCoordinateReferenceSystem, QgsVectorFileWriter, QgsCoordinateTransformContext, QgsMessageLog, Qgis
from PyQt5.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QPushButton,
    QFileDialog,
    QLabel,
    QMessageBox,
    QProgressBar
)
import os
import re
from osgeo import ogr
import shutil  # Ensure this import is at the top of your file
from PyQt5.uic import loadUiType
from qgis.gui import QgsFileWidget
from qgis.utils import iface
DialogUi, _ = loadUiType(
    os.path.join(os.path.dirname(__file__), "../ui/loader.ui")
)
import processing


class LoaderDialog(QDialog,DialogUi):
    def __init__(self, iface):
        super().__init__()
        self.setupUi(self)  # Load the UI from the .ui file

        # Store the QGIS interface instance
        self.iface = iface
        
        # Set up the layout (removed since it's handled in the UI file)
        self.setWindowTitle("Data Source Manager | Map Generation")

        # Set up QgsFileWidget for Working Folder
        self.select_working_folder.setStorageMode(QgsFileWidget.StorageMode.GetDirectory)
        self.select_working_folder.setDialogTitle("Select Working Directory")

         # Set up QgsFileWidget for base layer selection
        self.select_baselayer.setStorageMode(QgsFileWidget.StorageMode.GetFile)
        self.select_baselayer.setDialogTitle("Select Base Layer")
        self.select_baselayer.setFilter("GeoPackage files (*.gpkg)")

        # Set up QgsFileWidget for reference data folder selection
        self.select_refdata.setStorageMode(QgsFileWidget.StorageMode.GetFile)
        self.select_refdata.setDialogTitle("Select Reference Data")
        self.select_refdata.fileChanged.connect(self.select_refdata_folder)  # Connect to the new method
        self.select_refdata.setFilter("GeoPackage files (*_RefData.gpkg)")

        # Set up QgsFileWidget for raster layer selection
        # self.select_rasterlayer.setStorageMode(QgsFileWidget.StorageMode.GetFile)  # Set to select a file
        # self.select_rasterlayer.setDialogTitle("Select Raster Layer")  # Set dialog title
        # self.select_rasterlayer.setFilter(" Raster Layer (*_img.gpkg);;GeoPackage files (*.gpkg)")

        self.run_button.clicked.connect(self.run_loading_process)

        # Progress bar for loading process
        self.progress_bar.setRange(0, 100)  # Set range for progress bar

        # Store the path or file selected by the user
        self.selected_folder = ""
        self.selected_workingfolder = ""
        self.qml_folder = ""  
        self.sf_qml_file = ""  
        self.gp_qml_file = ""  

    def zoom_to_layer(self):
        # Retrieve all layers in the project
        layers = QgsProject.instance().mapLayers().values()

        # Iterate through each layer
        for layer in layers:
            # Check if the layer's name ends with 'bgy'
            if layer.name().endswith('_ea'):
                # Get the extent of the layer
                extent = layer.extent()
                # Set the map canvas to the layer's extent
                iface.mapCanvas().setExtent(extent)
                iface.mapCanvas().refresh()
                print(f"Zoomed to the extent of the layer: {layer.name()}")
                break
        else:
            print("No layer found with a name ending with 'ea'.")


    def select_refdata_folder(self):
        """Handle the selection of the reference data folder."""
        self.refdata_folder = self.select_refdata.filePath()  # Get the selected refdata folder from QgsFileWidget
        if self.refdata_folder:
            print(f"Selected Reference Data Folder: {self.refdata_folder}")  # Log the selected folder
        else:
            print("No reference data folder selected.")

 
    def run_loading_process(self):
        """Load layers from the selected folder or GeoPackage file and apply QML styles."""
        # Get the selected GeoPackage file from QgsFileWidget
        self.selected_workingfolder = self.select_working_folder.filePath()  
        self.selected_file = self.select_baselayer.filePath()  
        if not self.selected_file:
            QMessageBox.warning(self, "Warning", "Please select a Base Layer file first.")
            return

        # Validate the selected GeoPackage file
        if not os.path.exists(self.selected_file) or not self.selected_file.endswith('.gpkg'):
            QMessageBox.critical(self, "Error", "Selected file is invalid or not a GeoPackage.")
            return

        # Extract the folder path from the selected file
        self.selected_folder = os.path.dirname(self.selected_file)
        if not os.path.exists(self.selected_folder):
            QMessageBox.critical(self, "Error", "Selected file does not exist.")
            return
        
        # self.selected_workingfolder = os.path.dirname(self.select_working_folder)
        # if not os.path.exists(self.selected_workingfolder):
        #     QMessageBox.critical(self, "Error", "Selected folder does not exist.")
        #     return

        # Load layers from the selected folder
        sf_layer, gp_layer, csv_layers, gpkg_layers = self.load_layers_from_folder(self.selected_workingfolder)
        self.sf_layer = sf_layer  # Store reference to SF layer
        self.gp_layer = gp_layer  # Store reference to GP layer

        # Get the current project instance
        project = QgsProject.instance()

        # Create a new group called "CBMS Form 8"
        root = project.layerTreeRoot()
        cbms_group = root.addGroup("CBMS Form 8")

        # Update progress bar
        self.progress_bar.setValue(10)  # Update progress

        # Add the SF and GP layers to the "CBMS Form 8" group if they are valid
        if sf_layer and sf_layer.isValid():
            project.addMapLayer(sf_layer, False)
            cbms_group.addLayer(sf_layer)
        else:
            QMessageBox.critical(self, "Error", "SF layer failed to load!")

        self.progress_bar.setValue(30)  # Update progress

        if gp_layer and gp_layer.isValid():
            project.addMapLayer(gp_layer, False)
            cbms_group.addLayer(gp_layer)
        else:
            QMessageBox.critical(self, "Error", "GP layer failed to load!")

        self.progress_bar.setValue(50)  # Update progress

        # Optionally, expand the group
        cbms_group.setExpanded(True)

         # Create a new group called "Reference Data"
        reference_data_group = root.addGroup("SFGP_RefData")
        reference_data_group.setExpanded(False)  # Optionally expand the group

        # Load GeoPackage layers from the selected reference data file (single file)
        if hasattr(self, 'refdata_folder') and self.refdata_folder:  # Keep the same attribute name
            if os.path.isfile(self.refdata_folder) and self.refdata_folder.endswith("_RefData.gpkg"):
                gpkg_path = self.refdata_folder  # Use the file path directly
                self.load_layers_from_geopackage(reference_data_group, gpkg_path)  # Load layers from the GeoPackage
                print(f"Loaded GeoPackage layers from reference data: {os.path.basename(gpkg_path)}")
            else:
                QMessageBox.critical(self, "Error", "The specified path is not a valid '_RefData.gpkg' file.")
                print("The specified path is not a valid '_RefData.gpkg' file.")


        # Create a new group called "Base Layers"
        base_layers_group = root.addGroup("Base Layers")
        base_layers_group.setExpanded(False)

        # Ensure a file is selected and is a GeoPackage
        if self.selected_file and self.selected_file.endswith('.gpkg'):
            selected_path = os.path.join(self.selected_folder, self.selected_file)
            
            if os.path.exists(selected_path):
                self.load_layers_from_geopackage(base_layers_group, selected_path)  # Load only the selected file
            else:
                QMessageBox.warning(self, "Warning", "Selected GeoPackage file does not exist.")
        else:
            QMessageBox.warning(self, "Warning", "No valid GeoPackage file selected.")



       

        # Load the raster layer from the selected file
        # raster_file = self.select_rasterlayer.filePath()  # Get the selected raster file path
        # if raster_file and os.path.exists(raster_file):
        #     # Remove the file extension from the base name
        #     layer_name = os.path.splitext(os.path.basename(raster_file))[0]

        #     # Create the raster layer with the modified name
        #     raster_layer = QgsRasterLayer(raster_file, layer_name)

        #     if raster_layer.isValid():
        #         project.addMapLayer(raster_layer, False)  # Add to project without adding to the map
        #         root.addLayer(raster_layer)  # Add to the root, next to the base layers group
        #     else:
        #         QMessageBox.critical(self, "Error", "Raster layer failed to load!")
        # else:
        #     QMessageBox.warning(self, "Warning", "Please select a valid raster file.")

        self.progress_bar.setValue(90)  # Update progress

        # Create a new group called "Value Relation"
        value_relation_group = root.addGroup("Value Relation")

        # Add the CSV layers to the "Value Relation" group
        for gpkg_layer in gpkg_layers:
            if gpkg_layer.isValid():
                project.addMapLayer(gpkg_layer, False)
                value_relation_group.addLayer(gpkg_layer)

        # Optionally, expand the group
        value_relation_group.setExpanded(False)

        
        # Call the function to execute the renaming
        rename_layers() 

        # Final print to confirm structure
        self.progress_bar.setValue(100)  # Update progress
        QMessageBox.information(self, "Success", "Layers imported and organized successfully!")

        # Change data source for the loaded layers
        for layer in [self.sf_layer, self.gp_layer] + gpkg_layers:
            if layer and layer.isValid():
                # Update the data source to the new path
                new_source = layer.source()  # Get the current source
                layer.setDataSource(new_source, layer.name(), "ogr")
                layer.updateExtents()  # Update extents after changing the data source

        # Auto-save the QGIS project to the selected folder
        project.write(os.path.join(self.selected_workingfolder, "autosave_project.qgs"))  # Save the project

        self.zoom_to_layer()
        self.accept()


    def load_layers_from_geopackage(self, base_layers_group, gpkg_path, target_crs="EPSG:4326"):
        """Load layers from a GeoPackage into a specified group, reproject them, fix geometries (if needed), and save back."""
        conn = ogr.Open(gpkg_path, 1)  # Open the GeoPackage in update mode
        if conn is None:
            QMessageBox.critical(self, "Error", f"Failed to open GeoPackage: {gpkg_path}")
            return

        # Define target CRS
        target_crs = QgsCoordinateReferenceSystem(target_crs)

        # Iterate through layers in the GeoPackage
        for i in range(conn.GetLayerCount() - 1, -1, -1):  # Iterate in reverse order to avoid index issues when deleting layers
            layer = conn.GetLayerByIndex(i)
            if not layer:
                continue
            layer_name = layer.GetName()

            # Remove unwanted layers
            if 'layer_styles' in layer_name:
                conn.DeleteLayer(i)
                continue

            # Load the layer into QGIS
            qgis_layer = QgsVectorLayer(f"{gpkg_path}|layername={layer_name}", layer_name, 'ogr')
            if not qgis_layer.isValid():
                QMessageBox.warning(self, "Load Error", f"Layer '{layer_name}' failed to load!")
                continue

            # Check if the layer is already reprojected and has valid geometries
            if qgis_layer.crs() == target_crs:
                invalid_features = [f for f in qgis_layer.getFeatures() if not f.geometry().isGeosValid()]
                if not invalid_features:
                    QgsMessageLog.logMessage(
                        f"Layer '{layer_name}' is already reprojected and has valid geometries. Skipping.",
                        "Loader"
                    )
                    # Add the existing layer to the project
                    QgsProject.instance().addMapLayer(qgis_layer, False)
                    base_layers_group.addLayer(qgis_layer)
                    continue

            try:
                # Reproject the layer if needed
                reprojected_layer = qgis_layer
                if qgis_layer.crs() != target_crs:
                    reprojected_layer = processing.run("native:reprojectlayer", {
                        'INPUT': qgis_layer,
                        'TARGET_CRS': target_crs,
                        'OUTPUT': 'memory:'
                    })['OUTPUT']
                    reprojected_layer.setName(layer_name)

                # Fix geometries
                fixed_layer = processing.run("native:fixgeometries", {
                    'INPUT': reprojected_layer,
                    'OUTPUT': 'memory:'
                })['OUTPUT']
                fixed_layer.setName(layer_name)

                # Save the fixed and reprojected layer back to the GeoPackage
                options = QgsVectorFileWriter.SaveVectorOptions()
                options.layerName = layer_name
                options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
                options.driverName = "GPKG"

                self.reprojected_layers = getattr(self, "reprojected_layers", [])

                result = QgsVectorFileWriter.writeAsVectorFormatV3(
                    fixed_layer, gpkg_path, QgsCoordinateTransformContext(), options
                )

                if result[0] == QgsVectorFileWriter.NoError:
                    self.reprojected_layers.append(layer_name)  # Add the reprojected layer name to the list
                    QMessageBox.warning(
                            self,
                            "Warning",
                            f"Layer '{layer_name}' reprojected. If you detected this, please repeat Data Source Manager | Map generation to process and load again to reflect the changes on the reprojected layer.\n\nAll reprojected layers so far:\n" + "\n".join(self.reprojected_layers)
                    )
                    QgsMessageLog.logMessage(
                    f"Layer '{layer_name}' reprojected and fixed geometries saved to the GeoPackage.",
                    "GeoPackage Loader"
                )
                else:
                    QMessageBox.critical(
                            self,
                            "Save Error",
                            f"Error saving layer '{layer_name}': {result[1]}"
                    )

                # Add the fixed layer to the project
                QgsProject.instance().addMapLayer(fixed_layer, False)
                base_layers_group.addLayer(fixed_layer)

            except Exception as e:
                QMessageBox.critical(self, "Processing Error", f"Error processing layer '{layer_name}': {str(e)}")

        # Clean up connection
        del conn



    # def load_layers_from_folder(self, folder_path):
    #     sf_layer = None
    #     gp_layer = None
    #     csv_layers = []

    #     # Regular expression to match 5-digit identifiers
    #     # five_digit_pattern = re.compile(r'^\d{5}\.gpkg$')

    #     # Define the path to the 'files' subfolder within the plugin folder
    #     BASE_DIR = os.path.dirname(__file__)
    #     files_folder_path = os.path.join(BASE_DIR, "files")

    #     # Check if the 'files' folder exists
    #     if not os.path.exists(files_folder_path):
    #         QMessageBox.critical(self, "Error", f"The 'files' directory does not exist: {files_folder_path}")
    #         return  # Exit the function if the directory does not exist

    #     # Iterate through all files in the 'files' subfolder
    #     for file in os.listdir(files_folder_path):
    #         file_path = os.path.join(files_folder_path, file)
    #         if file.endswith(".shp"):
    #             if "_SF" in file:
    #                 sf_layer = QgsVectorLayer(file_path, os.path.splitext(file)[0], "ogr")
    #                 if not sf_layer.isValid():
    #                     print(f"Failed to load SF layer from: {file_path}")  # Log the error
    #                 # Copy related files for _SF
    #                 for ext in ['shp', 'cpg', 'dbf', 'shx', 'qmd', 'prj']:
    #                     original_file = os.path.splitext(file)[0] + '.' + ext
    #                     if os.path.exists(os.path.join(files_folder_path, original_file)):
    #                         gpkg_files = [f for f in os.listdir(folder_path) if f.endswith('.gpkg') and ('_maplayers' in f or '_2024maplayers' in f)]
    #                         gpkg_prefix = os.path.splitext(gpkg_files[0])[0][:5] if gpkg_files else 'pppmmbbb'
    #                         new_file_name = f"{gpkg_prefix}_SF.{ext}"  # New name for the copied file
    #                         new_file_path = os.path.join(self.selected_workingfolder, new_file_name)
    #                         shutil.copy(os.path.join(files_folder_path, original_file), new_file_path)  # Copy the file
    #                         print(f"Copied and renamed {original_file} to {new_file_path}")  # Log the action
    #                 # Change data source to the new path (specifically the .shp file)
    #                 sf_shp_path = os.path.join(self.selected_workingfolder, f"{gpkg_prefix}_SF.shp")  # Ensure this points to the .shp file
    #                 sf_layer.setDataSource(sf_shp_path, os.path.splitext(file)[0], "ogr")  # {{ edit_1 }}
    #                 if not sf_layer.isValid():  # {{ edit_2 }}
    #                     print(f"Failed to set data source for SF layer: {sf_shp_path}")  # Log the error
    #             elif "_GP" in file:
    #                 gp_layer = QgsVectorLayer(file_path, os.path.splitext(file)[0], "ogr")
    #                 if not gp_layer.isValid():
    #                     print(f"Failed to load GP layer from: {file_path}")  # Log the error
    #                 # Copy related files for _GP
    #                 for ext in ['shp', 'cpg', 'dbf', 'shx', 'qmd', 'prj']:
    #                     original_file = os.path.splitext(file)[0] + '.' + ext
    #                     if os.path.exists(os.path.join(files_folder_path, original_file)):
    #                         # Extract the 5-digit prefix from the corresponding gpkg file
    #                         gpkg_files = [f for f in os.listdir(folder_path) if f.endswith('.gpkg') and ('_maplayers' in f or '_2024maplayers' in f)]
    #                         gpkg_prefix = os.path.splitext(gpkg_files[0])[0][:5] if gpkg_files else 'pppmmbbb'  # Get the first 5 digits of the first gpkg file
    #                         new_file_name = f"{gpkg_prefix}_GP.{ext}"  # New name for the copied file
    #                         new_file_path = os.path.join(self.selected_workingfolder, new_file_name)
    #                         shutil.copy(os.path.join(files_folder_path, original_file), new_file_path)
    #                         print(f"Copied and renamed {original_file} to {new_file_path}")  # Log the action
    #                 # Change data source to the new path (specifically the .shp file)
    #                 gp_shp_path = os.path.join(self.selected_workingfolder, f"{gpkg_prefix}_GP.shp")  # Ensure this points to the .shp file
    #                 gp_layer.setDataSource(gp_shp_path, os.path.splitext(file)[0], "ogr")  # {{ edit_3 }}
    #                 if not gp_layer.isValid():  # {{ edit_4 }}
    #                     print(f"Failed to set data source for GP layer: {gp_shp_path}")  # Log the error
    #         elif file.endswith(".csv"):
    #             # Load CSV layer with proper URI and UTF-8 encoding
    #             csv_layer = QgsVectorLayer(f"file:///{file_path}?delimiter=,&encoding=UTF-8", os.path.splitext(file)[0], "delimitedtext")  # {{ edit_1 }}
    #             if csv_layer.isValid():
    #                 csv_layers.append(csv_layer)
    #                 # Copy the CSV file to the selected folder
    #                 new_csv_path = os.path.join(self.selected_workingfolder, file)  # Define the new path
    #                 shutil.copy(file_path, new_csv_path)  # Copy the file

    #                 # Set the data source without encoding since it's already specified in the URI
    #                 csv_layer.setDataSource(new_csv_path, os.path.splitext(file)[0], "ogr")
    #                 print(f"Copied CSV file to: {new_csv_path}")  # Log the action

    #     return sf_layer, gp_layer, csv_layers, None  # Add a placeholder for the fourth value

  
   

    def load_layers_from_folder(self, folder_path):
        sf_layer = None
        gp_layer = None
        csv_layers = []
        gpkg_layers = []

        # Define the path to the 'files' subfolder within the plugin folder
        BASE_DIR = os.path.dirname(__file__)
        files_folder_path = os.path.join(BASE_DIR, "files")

        # Check if the 'files' folder exists
        if not os.path.exists(files_folder_path):
            QMessageBox.critical(self, "Error", f"The 'files' directory does not exist: {files_folder_path}")
            return  # Exit the function if the directory does not exist

        # Iterate through all files in the 'files' subfolder
        for file in os.listdir(files_folder_path):
            file_path = os.path.join(files_folder_path, file)
            if file.endswith(".shp"):
                if "_SF" in file:
                    sf_layer = QgsVectorLayer(file_path, os.path.splitext(file)[0], "ogr")
                    if not sf_layer.isValid():
                        print(f"Failed to load SF layer from: {file_path}")  # Log the error
                    # Copy related files for _SF
                    for ext in ['shp', 'cpg', 'dbf', 'shx', 'qmd', 'prj']:
                        original_file = os.path.splitext(file)[0] + '.' + ext
                        if os.path.exists(os.path.join(files_folder_path, original_file)):
                            gpkg_files = [f for f in os.listdir(folder_path) if f.endswith('.gpkg') and ('_maplayers' in f or '_2024maplayers' in f)]
                            gpkg_prefix = os.path.splitext(gpkg_files[0])[0][:5] if gpkg_files else 'pppmmbbb'
                            new_file_name = f"{gpkg_prefix}_SF.{ext}"  # New name for the copied file
                            new_file_path = os.path.join(self.selected_workingfolder, new_file_name)
                            shutil.copy(os.path.join(files_folder_path, original_file), new_file_path)  # Copy the file
                            print(f"Copied and renamed {original_file} to {new_file_path}")  # Log the action
                    # Change data source to the new path (specifically the .shp file)
                    sf_shp_path = os.path.join(self.selected_workingfolder, f"{gpkg_prefix}_SF.shp")  # Ensure this points to the .shp file
                    sf_layer.setDataSource(sf_shp_path, os.path.splitext(file)[0], "ogr")  # {{ edit_1 }}
                    if not sf_layer.isValid():  # {{ edit_2 }}
                        print(f"Failed to set data source for SF layer: {sf_shp_path}")  # Log the error
                elif "_GP" in file:
                    gp_layer = QgsVectorLayer(file_path, os.path.splitext(file)[0], "ogr")
                    if not gp_layer.isValid():
                        print(f"Failed to load GP layer from: {file_path}")  # Log the error
                    # Copy related files for _GP
                    for ext in ['shp', 'cpg', 'dbf', 'shx', 'qmd', 'prj']:
                        original_file = os.path.splitext(file)[0] + '.' + ext
                        if os.path.exists(os.path.join(files_folder_path, original_file)):
                            # Extract the 5-digit prefix from the corresponding gpkg file
                            gpkg_files = [f for f in os.listdir(folder_path) if f.endswith('.gpkg') and ('_maplayers' in f or '_2024maplayers' in f)]
                            gpkg_prefix = os.path.splitext(gpkg_files[0])[0][:5] if gpkg_files else 'pppmmbbb'  # Get the first 5 digits of the first gpkg file
                            new_file_name = f"{gpkg_prefix}_GP.{ext}"  # New name for the copied file
                            new_file_path = os.path.join(self.selected_workingfolder, new_file_name)
                            shutil.copy(os.path.join(files_folder_path, original_file), new_file_path)
                            print(f"Copied and renamed {original_file} to {new_file_path}")  # Log the action
                    # Change data source to the new path (specifically the .shp file)
                    gp_shp_path = os.path.join(self.selected_workingfolder, f"{gpkg_prefix}_GP.shp")  # Ensure this points to the .shp file
                    gp_layer.setDataSource(gp_shp_path, os.path.splitext(file)[0], "ogr")  # {{ edit_3 }}
                    if not gp_layer.isValid():  # {{ edit_4 }}
                        print(f"Failed to set data source for GP layer: {gp_shp_path}")  # Log the error

            # Process CSV files
            # elif file.endswith(".csv"):
            #     csv_layer = QgsVectorLayer(f"file:///{file_path}?delimiter=,&encoding=UTF-8", os.path.splitext(file)[0], "delimitedtext")
            #     if csv_layer.isValid():
            #         csv_layers.append(csv_layer)
            #         # Copy the CSV file to the selected folder
            #         new_csv_path = os.path.join(self.selected_workingfolder, file)
            #         shutil.copy(file_path, new_csv_path)
            #         # If you want the layer to refer to the new location, you can update the datasource:
            #         csv_layer.setDataSource(new_csv_path, os.path.splitext(file)[0], "ogr")
            #     else:
            #         print(f"CSV layer from {file_path} is not valid.")

            # Process GPKG files
            elif file.endswith(".gpkg"):
                # Only process the file if its name is exactly "Value Relation.gpkg"
                if file != "value_relation.gpkg":
                    continue

                try:
                    # Define the destination path for the GeoPackage file.
                    new_gpkg_path = os.path.join(self.selected_workingfolder, file)
                    
                    # Copy the GeoPackage file to the selected folder first (if it doesn't already exist).
                    if not os.path.exists(new_gpkg_path):
                        shutil.copy(file_path, new_gpkg_path)
                        print(f"Copied GPKG file to: {new_gpkg_path}")
                    else:
                        print(f"GPKG file already exists in destination: {new_gpkg_path}")

                    # Open the GeoPackage from the new location
                    conn = ogr.Open(new_gpkg_path)
                    if conn is None:
                        QMessageBox.critical(self, "Error", f"Failed to open GeoPackage: {new_gpkg_path}")
                        continue  # Skip this file and continue with the next

                    layer_count = conn.GetLayerCount()
                    if layer_count == 0:
                        QMessageBox.warning(self, "Warning", f"No layers found in GeoPackage: {new_gpkg_path}")
                        continue  # Skip to the next file

                    # Iterate through all layers in the GeoPackage
                    for i in range(layer_count):
                        layer = conn.GetLayerByIndex(i)
                        layer_name = layer.GetName()

                        # Skip any system/internal layers (e.g., layer_styles)
                        if 'layer_styles' in layer_name:
                            continue

                        # Construct the QGIS layer from the new file location.
                        qgis_layer = QgsVectorLayer(f"{new_gpkg_path}|layername={layer_name}", layer_name, 'ogr')
                        if qgis_layer.isValid():
                            # Add the layer to the QGIS project
                            QgsProject.instance().addMapLayer(qgis_layer, False)
                            gpkg_layers.append(qgis_layer)
                        else:
                            print(f"Layer '{layer_name}' in {new_gpkg_path} failed to load!")

                except Exception as e:
                    QMessageBox.critical(self, "Error", f"An error occurred while loading the GeoPackage: {str(e)}")


        return sf_layer, gp_layer, csv_layers, gpkg_layers
    

# Function to check and rename layers based on specified suffixes
def rename_layers():
    # Define the suffixes to check for and their corresponding new names
    suffixes_to_rename = {
        'bgy': 'bgy',
        'brgy': 'bgy',
        'ea2024': 'ea',
        'ea': 'ea',
        'bldg': 'bldgpts',
        'bldg_points' : 'bldgpts',
        'landmark': 'landmark',
        'landmarks': 'landmark',
        'road': 'road',
        'road_updated': 'road',
        'updated_road' : 'road',
        'updated_river' : 'river',
        'river': 'river',
        'river_updated' : 'river',
        'block': 'block',
        'Block': 'block',
        'block2024': 'block',
    }

    # Get all layers in the project
    layers = QgsProject.instance().mapLayers().values()
    
    for layer in layers:
        layer_name = layer.name()
        renamed = False  # Flag to track if a renaming has occurred
        
        for suffix, new_suffix in suffixes_to_rename.items():
            if suffix in layer_name and not layer_name.endswith(new_suffix):
                # Rename the layer to the new suffix
                new_name = layer_name.split(suffix)[0] + new_suffix
                layer.setName(new_name)
                output = f"Layer renamed to: {new_name}"
                renamed = True
                break  # Break after renaming for this layer
        
        if not renamed:
            output = f"No renaming needed for layer: {layer_name}"
        
        print(output)

# Call the function to execute the renaming
rename_layers()
